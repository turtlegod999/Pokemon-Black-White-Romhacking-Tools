Thanks for downloading this tool. I hope you'll have a nice hacking time with it :)


The games supported are Pok�mon Diamond, Pearl, Platinum, HeartGold, SoulSilver, Black, White, Black 2 and White 2. All languages work.


Tool made by Spiky-Eared Pichu with the help of Arc
Internal 3D renderer based on MKDS Course Modifier by Florian


Special thanks to the translators:

Italian: Pichu2000 and xAlien95
French: Link_971
German: Dragonflye
Chinese: Pokewiz000
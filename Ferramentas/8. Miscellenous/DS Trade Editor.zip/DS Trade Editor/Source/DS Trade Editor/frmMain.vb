﻿Imports System.IO
Imports System.Text

Public Class frmMain
    Dim PercorsoNARC, PercorsoMSG As String, filePrefix As String
    Dim ROMAperta As Boolean
    Public isVar As Boolean = False
    Dim count As Integer = 0
    Dim MSG As NarcReader, NARC As NarcReader
    Private Sub ApriROMToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ApriROMToolStripMenuItem.Click
        If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
            dlgOpen.Title = "Apri NARC..."
            dlgOpen.Filter = "Archivio NARC (*.narc)|*fld_trade.narc"
        Else
            dlgOpen.Title = "Open NARC..."
            dlgOpen.Filter = "NARC Archive (*.narc)|*fld_trade.narc"
        End If
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            PercorsoNARC = dlgOpen.FileName
            ROMAperta = True
            If (dlgOpen.SafeFileName = "fld_trade.narc") Then
                filePrefix = "DP"
            ElseIf (dlgOpen.SafeFileName = "pl_fld_trade.narc") Then
                filePrefix = "P"
            End If
        Else
            Exit Sub
        End If
        dlgOpen.Reset()
        If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
            dlgOpen.Title = "Apri NARC..."
            dlgOpen.Filter = "Archivio NARC (*.narc)|*msg.narc"
        Else
            dlgOpen.Title = "Open NARC..."
            dlgOpen.Filter = "NARC Archive (*.narc)|*msg.narc"
        End If
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            PercorsoMSG = dlgOpen.FileName
            MSG = New NarcReader(PercorsoMSG)
            NARC = New NarcReader(PercorsoNARC)
            LoadLists()
            LoadData()
        Else
            Exit Sub
        End If
    End Sub
    Private Sub LoadLists()
        cmbItem.Items.Clear()
        cmbPKMN1.Items.Clear()
        cmbPKMN2.Items.Clear()
        Dim MSGFile As New IO.FileStream(PercorsoMSG, IO.FileMode.Open, IO.FileAccess.Read), reader As New BinaryReader(MSGFile)
        If (filePrefix = "DP") Then
            reader.BaseStream.Seek(MSG.fe(362).Ofs, SeekOrigin.Begin)
            readText(reader, cmbPKMN1)
            reader.BaseStream.Seek(MSG.fe(362).Ofs, SeekOrigin.Begin)
            readText(reader, cmbPKMN2)
            reader.BaseStream.Seek(MSG.fe(345).Ofs, SeekOrigin.Begin)
            readText(reader, cmbItem)
        ElseIf (filePrefix = "P") Then
            reader.BaseStream.Seek(MSG.fe(412).Ofs, SeekOrigin.Begin)
            readText(reader, cmbPKMN1)
            reader.BaseStream.Seek(MSG.fe(412).Ofs, SeekOrigin.Begin)
            readText(reader, cmbPKMN2)
            reader.BaseStream.Seek(MSG.fe(392).Ofs, SeekOrigin.Begin)
            readText(reader, cmbItem)
        End If
        MSGFile.Close()
        reader.Close()
    End Sub
    Private Sub LoadData()
        If (ROMAperta = True) Then
            Dim INI As New FileIni("data.ini")
            INI.Carica()
            If (Mineropoli.Checked = True) Then
                LoadThis(NARC.fe(0).Ofs, PercorsoNARC, cmbPKMN2)
                LoadText(NARC.fe(0).Ofs + 32, PercorsoNARC, txtID)
                LoadThis(NARC.fe(0).Ofs + 60, PercorsoNARC, cmbItem)
                LoadThis(NARC.fe(0).Ofs + 76, PercorsoNARC, cmbPKMN1)
            ElseIf (Evopoli.Checked = True) Then
                LoadThis(NARC.fe(1).Ofs, PercorsoNARC, cmbPKMN2)
                LoadText(NARC.fe(1).Ofs + 32, PercorsoNARC, txtID)
                LoadThis(NARC.fe(1).Ofs + 60, PercorsoNARC, cmbItem)
                LoadThis(NARC.fe(1).Ofs + 76, PercorsoNARC, cmbPKMN1)
            ElseIf (Nevepoli.Checked = True) Then
                LoadThis(NARC.fe(2).Ofs, PercorsoNARC, cmbPKMN2)
                LoadText(NARC.fe(2).Ofs + 32, PercorsoNARC, txtID)
                LoadThis(NARC.fe(2).Ofs + 60, PercorsoNARC, cmbItem)
                LoadThis(NARC.fe(2).Ofs + 76, PercorsoNARC, cmbPKMN1)
            ElseIf (Percorso226.Checked = True) Then
                LoadThis(NARC.fe(3).Ofs, PercorsoNARC, cmbPKMN2)
                LoadText(NARC.fe(3).Ofs + 32, PercorsoNARC, txtID)
                LoadThis(NARC.fe(3).Ofs + 60, PercorsoNARC, cmbItem)
                LoadThis(NARC.fe(3).Ofs + 76, PercorsoNARC, cmbPKMN1)
            End If
        End If
    End Sub

    Private Sub SalvaROMToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalvaROMToolStripMenuItem.Click
        If (ROMAperta = True) Then
            Dim INI As New FileIni("data.ini")
            INI.Carica()
            If (Mineropoli.Checked = True) Then
                WriteThis(NARC.fe(0).Ofs, PercorsoNARC, cmbPKMN2)
                WriteText(NARC.fe(0).Ofs + 32, PercorsoNARC, txtID)
                WriteThis(NARC.fe(0).Ofs + 60, PercorsoNARC, cmbItem)
                WriteThis(NARC.fe(0).Ofs + 76, PercorsoNARC, cmbPKMN1)
            ElseIf (Evopoli.Checked = True) Then
                WriteThis(NARC.fe(1).Ofs, PercorsoNARC, cmbPKMN2)
                WriteText(NARC.fe(1).Ofs + 32, PercorsoNARC, txtID)
                WriteThis(NARC.fe(1).Ofs + 60, PercorsoNARC, cmbItem)
                WriteThis(NARC.fe(1).Ofs + 76, PercorsoNARC, cmbPKMN1)
            ElseIf (Nevepoli.Checked = True) Then
                WriteThis(NARC.fe(2).Ofs, PercorsoNARC, cmbPKMN2)
                WriteText(NARC.fe(2).Ofs + 32, PercorsoNARC, txtID)
                WriteThis(NARC.fe(2).Ofs + 60, PercorsoNARC, cmbItem)
                WriteThis(NARC.fe(2).Ofs + 76, PercorsoNARC, cmbPKMN1)
            ElseIf (Percorso226.Checked = True) Then
                WriteThis(NARC.fe(3).Ofs, PercorsoNARC, cmbPKMN2)
                WriteText(NARC.fe(3).Ofs + 32, PercorsoNARC, txtID)
                WriteThis(NARC.fe(3).Ofs + 60, PercorsoNARC, cmbItem)
                WriteThis(NARC.fe(3).Ofs + 76, PercorsoNARC, cmbPKMN1)
            End If
            If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then 'Notare la condizione =D, non ho voglia di aprire ogni volta un file INI!
                MsgBox("Dati salvati! =)", vbInformation, "DS Trade Editor")
            Else
                MsgBox("Data saved! =)", vbInformation, "DS Trade Editor")
            End If
        Else
            If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then 'Fare così è molto più rapido =)
                MsgBox("Non è aperta alcuna ROM!", vbExclamation, "Errore")
            Else
                MsgBox("You didn't load anything!", vbExclamation, "Error")
            End If
        End If
    End Sub

    Private Sub InformazioniToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InformazioniToolStripMenuItem.Click
        frmAbout.Show()
    End Sub

    Private Sub EsciToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles EsciToolStripMenuItem.Click
        If (ROMAperta = True) Then
            Dim risp As String
            If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
                risp = MsgBox("Hai aperto una ROM. Potresti perdere eventuali modifiche se non le si ha salvate. Chiudere comunque?", vbYesNo, "ROM aperta. Chiudere?")
            Else
                risp = MsgBox("You've loaded a ROM. If you didn't save any changes, you'll lose them. Exit anyway?", vbYesNo, "ROM Loaded. Exit anyway?")
            End If
            If (risp = vbYes) Then
                Me.Close()
            End If
        Else
            Me.Close()
        End If
    End Sub
#Region "Boh... =)"
    Private Sub Mineropoli_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles Mineropoli.CheckedChanged
        LoadData()
    End Sub

    Private Sub Evopoli_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles Evopoli.CheckedChanged
        LoadData()
    End Sub

    Private Sub Nevepoli_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles Nevepoli.CheckedChanged
        LoadData()
    End Sub

    Private Sub Percorso226_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles Percorso226.CheckedChanged
        LoadData()
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtID.KeyPress
        If (Not IsNumeric(e.KeyChar)) And (Asc(e.KeyChar) <> 8) Then
            e.Handled = True
        End If
    End Sub
#End Region
#Region "Language stuff"
    Private Sub ItalianoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ItalianoToolStripMenuItem.Click
        Dim INI As New FileIni("data.ini")
        INI.Carica()
        INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = "1"
        ApriROMToolStripMenuItem.Text = "Apri NARC..."
        SalvaROMToolStripMenuItem.Text = "Salva NARC..."
        EsciToolStripMenuItem.Text = "Esci"
        AiutoToolStripMenuItem.Text = "Aiuto"
        InformazioniToolStripMenuItem.Text = "Informazioni"
        LinguaToolStripMenuItem.Text = "Lingua"
        ItalianoToolStripMenuItem.Text = "Italiano"
        IngleseToolStripMenuItem.Text = "Inglese"
        GroupBox1.Text = "Seleziona lo scambio"
        GroupBox2.Text = "Dettagli Scambio"
        Label1.Text = "Pokémon richiesto:"
        Label2.Text = "Pokémon ricevuto:"
        Label3.Text = "Strumento ricevuto:"
        Label5.Text = "ID Pokémon:"
        Mineropoli.Text = "Mineropoli"
        Evopoli.Text = "Evopoli"
        Nevepoli.Text = "Nevepoli"
        Percorso226.Text = "Percorso 226"
        INI.Salva()
    End Sub

    Private Sub IngleseToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles IngleseToolStripMenuItem.Click
        Dim INI As New FileIni("data.ini")
        INI.Carica()
        INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = "0"
        ApriROMToolStripMenuItem.Text = "Open NARC..."
        SalvaROMToolStripMenuItem.Text = "Save NARC..."
        EsciToolStripMenuItem.Text = "Exit"
        AiutoToolStripMenuItem.Text = "Help"
        InformazioniToolStripMenuItem.Text = "About"
        LinguaToolStripMenuItem.Text = "Language"
        ItalianoToolStripMenuItem.Text = "Italian"
        IngleseToolStripMenuItem.Text = "English"
        GroupBox1.Text = "Select trade"
        GroupBox2.Text = "Trade Details"
        Label1.Text = "Required pokémon:"
        Label2.Text = "Received pokémon:"
        Label3.Text = "Received item:"
        Label5.Text = "Pokémon's ID:"
        Mineropoli.Text = "Oreburgh City"
        Evopoli.Text = "Eterna City"
        Nevepoli.Text = "Snowpoint City"
        Percorso226.Text = "Route 226"
        INI.Salva()
    End Sub

    Private Sub frmMain_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim INI As New FileIni("data.ini")
        INI.Carica()
        If (INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = 0) Then
            ApriROMToolStripMenuItem.Text = "Open NARC..."
            SalvaROMToolStripMenuItem.Text = "Save NARC..."
            EsciToolStripMenuItem.Text = "Exit"
            AiutoToolStripMenuItem.Text = "Help"
            InformazioniToolStripMenuItem.Text = "About"
            LinguaToolStripMenuItem.Text = "Language"
            ItalianoToolStripMenuItem.Text = "Italian"
            IngleseToolStripMenuItem.Text = "English"
            GroupBox1.Text = "Select trade"
            GroupBox2.Text = "Trade Details"
            Label1.Text = "Required pokémon:"
            Label2.Text = "Received pokémon:"
            Label3.Text = "Received item:"
            Label5.Text = "Pokémon's ID:"
            Mineropoli.Text = "Oreburgh City"
            Evopoli.Text = "Eterna City"
            Nevepoli.Text = "Snowpoint City"
            Percorso226.Text = "Route 226"
        ElseIf (INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = 1) Then
            ApriROMToolStripMenuItem.Text = "Apri NARC..."
            SalvaROMToolStripMenuItem.Text = "Salva NARC..."
            EsciToolStripMenuItem.Text = "Esci"
            AiutoToolStripMenuItem.Text = "Aiuto"
            InformazioniToolStripMenuItem.Text = "Informazioni"
            LinguaToolStripMenuItem.Text = "Lingua"
            ItalianoToolStripMenuItem.Text = "Italiano"
            IngleseToolStripMenuItem.Text = "Inglese"
            GroupBox1.Text = "Seleziona lo scambio"
            GroupBox2.Text = "Dettagli Scambio"
            Label1.Text = "Pokémon richiesto:"
            Label2.Text = "Pokémon ricevuto:"
            Label3.Text = "Strumento ricevuto:"
            Label5.Text = "ID Pokémon:"
            Mineropoli.Text = "Mineropoli"
            Evopoli.Text = "Evopoli"
            Nevepoli.Text = "Nevepoli"
            Percorso226.Text = "Percorso 226"
        End If
    End Sub
#End Region
    Private Sub readText(reader As BinaryReader, combo As ComboBox)
        Dim numTextFile As UShort
        Dim key As UInt32
        numTextFile = reader.ReadUInt16
        key = reader.ReadUInt16
        key = (key * &H2FD) And &HFFFF
        Dim textList As New List(Of TextStruct)()
        For i = 0 To numTextFile - 1
            Dim actualTextFile = New TextStruct
            actualTextFile.key2 = (key * (i + 1) And &HFFFF)
            actualTextFile.realKey = actualTextFile.key2 Or (actualTextFile.key2 << 16)
            actualTextFile.startOffset = reader.ReadInt32() Xor actualTextFile.realKey
            actualTextFile.size = reader.ReadInt32() Xor actualTextFile.realKey
            textList.Add(actualTextFile)
        Next
        For i = 0 To numTextFile - 1
            Dim actualTextFile = textList(i)
            key = (&H91BD3 * (i + 1)) And &HFFFF
            Dim str As New StringBuilder()
            isVar = False
            For k = 0 To actualTextFile.size - 1
                If (count = 4) Then
                    str.Append("] ")
                    isVar = False
                    count = 0
                End If
                Dim value = reader.ReadUInt16() Xor key
                Dim car = getCharacter(value)
                If (car = "[]") Then
                    str.Append(" [VAR ")
                    isVar = True
                Else
                    str.Append(car)
                End If
                If (isVar) Then count = count + 1
                key = key + &H493D
                key = key And &HFFFF
            Next
            actualTextFile.text = str.ToString
            combo.Items.Add(actualTextFile.text)
            textList(i) = actualTextFile
        Next
    End Sub

    Public Structure TextStruct
        Public id As Integer
        Public startOffset As Integer
        Public text As [String]
        Public key2 As Integer
        Public realKey As Integer
        Public size As Integer
    End Structure
End Class

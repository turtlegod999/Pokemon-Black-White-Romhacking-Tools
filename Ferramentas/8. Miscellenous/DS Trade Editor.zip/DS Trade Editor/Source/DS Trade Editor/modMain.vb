﻿Module modMain
    Public Sub WriteThis(Offset As Integer, ROMPath As String, List As ComboBox)
        Dim ROMFile As New IO.FileStream(ROMPath, IO.FileMode.Open, IO.FileAccess.Write)
        Dim writer As New IO.BinaryWriter(ROMFile)
        writer.BaseStream.Seek(Offset, IO.SeekOrigin.Begin)
        writer.Write(CUShort(List.SelectedIndex))
        writer.Close()
        ROMFile.Close()
    End Sub
    Public Sub LoadThis(Offset As Integer, ROMPath As String, List As ComboBox)
        Dim ROMFile As New IO.FileStream(ROMPath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim reader As New IO.BinaryReader(ROMFile), value As UShort
        reader.BaseStream.Seek(Offset, IO.SeekOrigin.Begin)
        value = reader.ReadUInt16()
        List.SelectedIndex = CInt(value)
        reader.Close()
        ROMFile.Close()
    End Sub
    Public Sub WriteText(Offset As Integer, ROMPath As String, Text As TextBox)
        Dim ROMFile As New IO.FileStream(ROMPath, IO.FileMode.Open, IO.FileAccess.Write)
        Dim writer As New IO.BinaryWriter(ROMFile)
        writer.BaseStream.Seek(Offset, IO.SeekOrigin.Begin)
        writer.Write(CUShort(Text.Text))
        writer.Close()
        ROMFile.Close()
    End Sub
    Public Sub LoadText(Offset As Integer, ROMPath As String, Text As TextBox)
        Dim ROMFile As New IO.FileStream(ROMPath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim reader As New IO.BinaryReader(ROMFile), value As UShort
        reader.BaseStream.Seek(Offset, IO.SeekOrigin.Begin)
        value = reader.ReadUInt16()
        Text.Text = CInt(value)
        reader.Close()
        ROMFile.Close()
    End Sub
    Public Function getCharacter(p As Integer) As String
        Select Case p
            Case &H0
                Return "0 "
            Case &H1
                Return "1 "
            Case &HA2
                Return "０"
            Case &HA3
                Return "１"
            Case &HA4
                Return "２"
            Case &HA5
                Return "３"
            Case &HA6
                Return "４"
            Case &HA7
                Return "５"
            Case &HA8
                Return "６"
            Case &HA9
                Return "７"
            Case &HAA
                Return "８"
            Case &HAB
                Return "９"
            Case &HAC
                Return "Ａ"
            Case &HAD
                Return "Ｂ"
            Case &HAE
                Return "Ｃ"
            Case &HAF
                Return "Ｄ"
            Case &HB0
                Return "Ｅ"
            Case &HB1
                Return "Ｆ"
            Case &HB2
                Return "Ｇ"
            Case &HB3
                Return "Ｈ"
            Case &HB4
                Return "Ｉ"
            Case &HB5
                Return "Ｊ"
            Case &HB6
                Return "Ｋ"
            Case &HB7
                Return "Ｌ"
            Case &HB8
                Return "Ｍ"
            Case &HB9
                Return "Ｎ"
            Case &HBA
                Return "Ｏ"
            Case &HBB
                Return "Ｐ"
            Case &HBC
                Return "Ｑ"
            Case &HBD
                Return "Ｒ"
            Case &HBE
                Return "Ｓ"
            Case &HBF
                Return "Ｔ"
            Case &HC0
                Return "Ｕ"
            Case &HC1
                Return "Ｖ"
            Case &HC2
                Return "Ｗ"
            Case &HC3
                Return "Ｘ"
            Case &HC4
                Return "Ｙ"
            Case &HC5
                Return "Ｚ"
            Case &HC6
                Return "ａ"
            Case &HC7
                Return "ｂ"
            Case &HC8
                Return "c"
            Case &HC9
                Return "d"
            Case &HCA
                Return "e"
            Case &HCB
                Return "f"
            Case &HCC
                Return "g"
            Case &HCD
                Return "h"
            Case &HCE
                Return "i"
            Case &HCF
                Return "j"
            Case &HD0
                Return "k"
            Case &HD1
                Return "l"
            Case &HD2
                Return "m"
            Case &HD3
                Return "n"
            Case &HD4
                Return "o"
            Case &HD5
                Return "p"
            Case &HD6
                Return "q"
            Case &HD7
                Return "r"
            Case &HD8
                Return "s"
            Case &HD9
                Return "t"
            Case &HDA
                Return "u"
            Case &HDB
                Return "v"
            Case &HDC
                Return "w"
            Case &HDD
                Return "x"
            Case &HDE
                Return "y"
            Case &HDF
                Return "z"
            Case &H100
                If frmMain.isVar Then
                    Return "POKE: "
                End If
                Exit Select
            Case &H101
                If frmMain.isVar Then
                    Return "POKE2: "
                End If
                Exit Select
            Case &H103
                If frmMain.isVar Then
                    Return "NAME: "
                End If
                Exit Select
            Case &H104
                If frmMain.isVar Then
                    Return "PLACE: "
                End If
                Exit Select
            Case &H106
                If frmMain.isVar Then
                    Return "MOVE: "
                End If
                Exit Select
            Case &H107
                If frmMain.isVar Then
                    Return "NAT: "
                End If
                Exit Select
            Case &H108
                If frmMain.isVar Then
                    Return "ITEM: "
                End If
                Exit Select
            Case &H10A
                If frmMain.isVar Then
                    Return "POFFIN ITEM: "
                End If
                Exit Select
            Case &H10E
                If frmMain.isVar Then
                    Return "TRAINER: "
                End If
                Exit Select
            Case &H118
                If frmMain.isVar Then
                    Return "KEY ITEM: "
                End If
                Exit Select
            Case &H11F
                If frmMain.isVar Then
                    Return "ACC.: "
                End If
                Exit Select
            Case &H121
                Return "0"
            Case &H122
                Return "1"
            Case &H123
                Return "2"
            Case &H124
                Return "3"
            Case &H125
                Return "4"
            Case &H126
                Return "5"
            Case &H127
                Return "6"
            Case &H128
                Return "7"
            Case &H129
                Return "8"
            Case &H12A
                Return "9"
            Case &H12B
                Return "A"
            Case &H12C
                Return "B"
            Case &H12D
                Return "C"
            Case &H12E
                Return "D"
            Case &H12F
                Return "E"
            Case &H130
                Return "F"
            Case &H131
                Return "G"
            Case &H132
                If frmMain.isVar Then
                    Return "NUM: "
                End If
                Return "H"
            Case &H133
                If frmMain.isVar Then
                    Return "LEVEL: "
                End If
                Return "I"
            Case &H134
                If frmMain.isVar Then
                    Return "NUM2: "
                End If
                Return "J"
            Case &H135
                If frmMain.isVar Then
                    Return "NUM3: "
                End If
                Return "K"
            Case &H136
                Return "L"
            Case &H137
                If frmMain.isVar Then
                    Return "MONEY: "
                End If
                Return "M"
            Case &H138
                Return "N"
            Case &H139
                Return "O"
            Case &H13A
                Return "P"
            Case &H13B
                Return "Q"
            Case &H13C
                Return "R"
            Case &H13D
                Return "S"
            Case &H13E
                Return "T"
            Case &H13F
                Return "U"
            Case &H140
                Return "V"
            Case &H141
                Return "W"
            Case &H142
                Return "X"
            Case &H143
                Return "Y"
            Case &H144
                Return "Z"
            Case &H145
                Return "a"
            Case &H146
                Return "b"
            Case &H147
                Return "c"
            Case &H148
                Return "d"
            Case &H149
                Return "e"
            Case &H14A
                Return "f"
            Case &H14B
                Return "g"
            Case &H14C
                Return "h"
            Case &H14D
                Return "i"
            Case &H14E
                Return "j"
            Case &H14F
                Return "k"
            Case &H150
                Return "l"
            Case &H151
                Return "m"
            Case &H152
                Return "n"
            Case &H153
                Return "o"
            Case &H154
                Return "p"
            Case &H155
                Return "q"
            Case &H156
                Return "r"
            Case &H157
                Return "s"
            Case &H158
                Return "t"
            Case &H159
                Return "u"
            Case &H15A
                Return "v"
            Case &H15B
                Return "w"
            Case &H15C
                Return "x"
            Case &H15D
                Return "y"
            Case &H15E
                Return "z"
            Case &H15F
                Return "À"
            Case &H160
                Return "Á"
            Case &H161
                Return "Â"
            Case &H162
                Return "Ţ"
            Case &H163
                Return "Ä"
            Case &H164
                Return "Ť"
            Case &H165
                Return "ť"
            Case &H166
                Return "Ç"
            Case &H167
                Return "È"
            Case &H168
                Return "É"
            Case &H169
                Return "Ê"
            Case &H16A
                Return "Ë"
            Case &H16B
                Return "Ì"
            Case &H16C
                Return "Í"
            Case &H16D
                Return "Î"
            Case &H16E
                Return "Ï"
            Case &H16F
                Return "ů"
            Case &H170
                Return "Ñ"
            Case &H171
                Return "Ò"
            Case &H172
                Return "Ó"
            Case &H173
                Return "Ô"
            Case &H174
                Return "Ŵ"
            Case &H175
                Return "Ö"
            Case &H176
                Return "×"
            Case &H177
                Return "ŷ"
            Case &H178
                Return "Ù"
            Case &H179
                Return "Ú"
            Case &H17A
                Return "Û"
            Case &H17B
                Return "Ü"
            Case &H17C
                Return "ż"
            Case &H17D
                Return "Ž"
            Case &H17E
                Return "ß"
            Case &H17F
                Return "à"
            Case &H180
                Return "á"
            Case &H181
                Return "â"
            Case &H182
                Return "Ƃ"
            Case &H183
                Return "ä"
            Case &H184
                Return "Ƅ"
            Case &H185
                Return "ƅ"
            Case &H186
                Return "ç"
            Case &H187
                Return "è"
            Case &H188
                Return "é"
            Case &H189
                Return "ê"
            Case &H18A
                Return "ë"
            Case &H18B
                Return "ì"
            Case &H18C
                Return "í"
            Case &H18D
                Return "î"
            Case &H18E
                Return "ï"
            Case &H18F
                Return "Ə"
            Case &H190
                Return "ñ"
            Case &H191
                Return "ò"
            Case &H192
                Return "ó"
            Case &H193
                Return "ô"
            Case &H194
                Return "Ɣ"
            Case &H195
                Return "ö"
            Case &H196
                Return "÷"
            Case &H197
                Return "Ɨ"
            Case &H198
                Return "ù"
            Case &H199
                Return "ú"
            Case &H19A
                Return "û"
            Case &H19B
                Return "ü"
            Case &H19C
                Return "Ɯ"
            Case &H19D
                Return "Ɲ"
            Case &H19E
                Return "ƞ"
            Case &H19F
                Return "Œ"
            Case &H1A0
                Return "œ"
            Case &H1A1
                Return "ơ"
            Case &H1A2
                Return "Ƣ"
            Case &H1A3
                Return "ª"
            Case &H1A4
                Return "º"
            Case &H1A5
                Return "ᵉʳ"
            Case &H1A6
                Return "ʳᵉ"
            Case &H1A7
                Return "ʳ"
            Case &H1A8
                Return "¥"
            Case &H1A9
                Return "¡"
            Case &H1AA
                Return "¿"
            Case &H1AB
                Return "!"
            Case &H1AC
                Return "?"
            Case &H1AD
                Return ","
            Case &H1AE
                Return "."
            Case &H1AF
                Return "..."
            Case &H1B0
                Return "·"
            Case &H1B1
                Return "/"
            Case &H1B2
                Return "‘"
            Case &H1B3
                Return "'"
            Case &H1B4
                Return """"
            Case &H1B5
                Return """"
            Case &H1B6
                Return "„"
            Case &H1B7
                Return "«"
            Case &H1B8
                Return "»"
            Case &H1B9
                Return "("
            Case &H1BA
                Return ")"
            Case &H1BB
                Return "♂"
            Case &H1BC
                Return "♀"
            Case &H1BD
                Return "+"
            Case &H1BE
                Return "-"
            Case &H1BF
                Return "*"
            Case &H1C0
                Return "#"
            Case &H1C1
                Return "="
            Case &H1C2
                Return ChrW(7) & "nd"
            Case &H1C3
                Return "~"
            Case &H1C4
                Return ":"
            Case &H1C5
                Return ";"
            Case &H1C6
                Return "„"
            Case &H1C7
                Return "«"
            Case &H1C8
                Return "»"
            Case &H1C9
                Return "("
            Case &H1CA
                Return ")"
            Case &H1CB
                Return "♂"
            Case &H1CC
                Return "♀"
            Case &H1CD
                Return "+"
            Case &H1CE
                Return "-"
            Case &H1CF
                Return "*"
            Case &H1D2
                Return "%"
            Case &H1DE
                Return " "
            Case &H203
                If frmMain.isVar Then
                    Return "COLOR: "
                End If
                Exit Select
            Case &HE000
                Return "/n"
            Case &H25BC
                Return "/r"
            Case &H25BD
                Return "/v"
            Case &HFFFE
                Return "[]"
            Case &HFFFF
                Return vbNullChar
        End Select
        Return p.ToString() + " "
    End Function
End Module
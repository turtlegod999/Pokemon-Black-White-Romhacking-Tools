﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApriROMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalvaROMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.EsciToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AiutoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformazioniToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LinguaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItalianoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IngleseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.dlgOpen = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Percorso226 = New System.Windows.Forms.RadioButton()
        Me.Nevepoli = New System.Windows.Forms.RadioButton()
        Me.Evopoli = New System.Windows.Forms.RadioButton()
        Me.Mineropoli = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmbItem = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbPKMN2 = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbPKMN1 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.mnuMain.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.AiutoToolStripMenuItem})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(395, 24)
        Me.mnuMain.TabIndex = 0
        Me.mnuMain.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApriROMToolStripMenuItem, Me.SalvaROMToolStripMenuItem, Me.ToolStripMenuItem1, Me.EsciToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ApriROMToolStripMenuItem
        '
        Me.ApriROMToolStripMenuItem.Name = "ApriROMToolStripMenuItem"
        Me.ApriROMToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ApriROMToolStripMenuItem.Text = "Apri NARC..."
        '
        'SalvaROMToolStripMenuItem
        '
        Me.SalvaROMToolStripMenuItem.Name = "SalvaROMToolStripMenuItem"
        Me.SalvaROMToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SalvaROMToolStripMenuItem.Text = "Salva NARC..."
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(149, 6)
        '
        'EsciToolStripMenuItem
        '
        Me.EsciToolStripMenuItem.Name = "EsciToolStripMenuItem"
        Me.EsciToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.EsciToolStripMenuItem.Text = "Esci"
        '
        'AiutoToolStripMenuItem
        '
        Me.AiutoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InformazioniToolStripMenuItem, Me.LinguaToolStripMenuItem})
        Me.AiutoToolStripMenuItem.Name = "AiutoToolStripMenuItem"
        Me.AiutoToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.AiutoToolStripMenuItem.Text = "Aiuto"
        '
        'InformazioniToolStripMenuItem
        '
        Me.InformazioniToolStripMenuItem.Name = "InformazioniToolStripMenuItem"
        Me.InformazioniToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.InformazioniToolStripMenuItem.Text = "Informazioni"
        '
        'LinguaToolStripMenuItem
        '
        Me.LinguaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ItalianoToolStripMenuItem, Me.IngleseToolStripMenuItem})
        Me.LinguaToolStripMenuItem.Name = "LinguaToolStripMenuItem"
        Me.LinguaToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LinguaToolStripMenuItem.Text = "Lingua"
        '
        'ItalianoToolStripMenuItem
        '
        Me.ItalianoToolStripMenuItem.Image = CType(resources.GetObject("ItalianoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ItalianoToolStripMenuItem.Name = "ItalianoToolStripMenuItem"
        Me.ItalianoToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.ItalianoToolStripMenuItem.Text = "Italiano"
        '
        'IngleseToolStripMenuItem
        '
        Me.IngleseToolStripMenuItem.Image = CType(resources.GetObject("IngleseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.IngleseToolStripMenuItem.Name = "IngleseToolStripMenuItem"
        Me.IngleseToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.IngleseToolStripMenuItem.Text = "Inglese"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Percorso226)
        Me.GroupBox1.Controls.Add(Me.Nevepoli)
        Me.GroupBox1.Controls.Add(Me.Evopoli)
        Me.GroupBox1.Controls.Add(Me.Mineropoli)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 164)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(372, 47)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Seleziona lo scambio"
        '
        'Percorso226
        '
        Me.Percorso226.AutoSize = True
        Me.Percorso226.Location = New System.Drawing.Point(278, 19)
        Me.Percorso226.Name = "Percorso226"
        Me.Percorso226.Size = New System.Drawing.Size(88, 17)
        Me.Percorso226.TabIndex = 2
        Me.Percorso226.TabStop = True
        Me.Percorso226.Text = "Percorso 226"
        Me.Percorso226.UseVisualStyleBackColor = True
        '
        'Nevepoli
        '
        Me.Nevepoli.AutoSize = True
        Me.Nevepoli.Location = New System.Drawing.Point(185, 19)
        Me.Nevepoli.Name = "Nevepoli"
        Me.Nevepoli.Size = New System.Drawing.Size(67, 17)
        Me.Nevepoli.TabIndex = 2
        Me.Nevepoli.TabStop = True
        Me.Nevepoli.Text = "Nevepoli"
        Me.Nevepoli.UseVisualStyleBackColor = True
        '
        'Evopoli
        '
        Me.Evopoli.AutoSize = True
        Me.Evopoli.Location = New System.Drawing.Point(98, 19)
        Me.Evopoli.Name = "Evopoli"
        Me.Evopoli.Size = New System.Drawing.Size(60, 17)
        Me.Evopoli.TabIndex = 1
        Me.Evopoli.TabStop = True
        Me.Evopoli.Text = "Evopoli"
        Me.Evopoli.UseVisualStyleBackColor = True
        '
        'Mineropoli
        '
        Me.Mineropoli.AutoSize = True
        Me.Mineropoli.Location = New System.Drawing.Point(6, 19)
        Me.Mineropoli.Name = "Mineropoli"
        Me.Mineropoli.Size = New System.Drawing.Size(73, 17)
        Me.Mineropoli.TabIndex = 0
        Me.Mineropoli.TabStop = True
        Me.Mineropoli.Text = "Mineropoli"
        Me.Mineropoli.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtID)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.cmbItem)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.cmbPKMN2)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.cmbPKMN1)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 217)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(372, 116)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Dettagli Scambio"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(114, 87)
        Me.txtID.MaxLength = 5
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(61, 20)
        Me.txtID.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(9, 90)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(101, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "ID Pokémon:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmbItem
        '
        Me.cmbItem.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbItem.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbItem.FormattingEnabled = True
        Me.cmbItem.Items.AddRange(New Object() {"???", "Master Ball ", "Ultra Ball ", "Mega Ball ", "Poké Ball ", "Safari Ball ", "Rete Ball ", "Sub Ball ", "Minor Ball ", "Bis Ball ", "Timer Ball ", "Chic Ball ", "Premier Ball ", "Scuro Ball ", "Cura Ball ", "Velox Ball ", "Pregio Ball ", "Pozione ", "Antidoto ", "Antiscottatura ", "Antigelo ", "Sveglia ", "Antiparalisi ", "Ricarica Totale ", "Pozione Max ", "Iperpozione ", "Superpozione ", "Cura Totale ", "Revitalizzante ", "Revitalizzante Max ", "Acqua Fresca ", "Gassosa ", "Lemonsucco ", "Latte Mumu ", "Polvenergia ", "Radicenergia ", "Polvocura ", "Vitalerba ", "Etere ", "Etere Max ", "Elisir ", "Elisir Max ", "Lavottino ", "Succo di Bacca ", "Ceneremagica ", "PS Su ", "Proteina ", "Ferro ", "Carburante ", "Calcio ", "Caramella Rara ", "PP-Su ", "Zinco ", "PP-Max ", "Dolce Gateau ", "Superguardia ", "Supercolpo ", "Attacco X ", "Difesa X ", "Velocità X ", "Precisione X ", "Special X ", "Dif. Sp. X ", "Poké Bambola ", "Coda Skitty ", "Flauto Blu ", "Flauto Giallo ", "Flauto Rosso ", "Flauto Nero ", "Flauto Bianco ", "Sale Ondoso ", "Gusciondoso ", "Coccio Rosso ", "Coccio Blu ", "Coccio Giallo ", "Coccio Verde ", "Superrepellente ", "Repellente Max ", "Fune di Fuga ", "Repellente ", "Pietrasolare ", "Pietralunare ", "Pietrafocaia ", "Pietratuono ", "Pietraidrica ", "Pietrafoglia ", "Minifungo ", "Grande Fungo ", "Perla ", "Grande Perla ", "Polvostella ", "Pezzo Stella ", "Pepita ", "Squama Cuore ", "Miele ", "Fertilrapido ", "Fertilidro ", "Fertilsaldo ", "Fertilcolla ", "Radifossile ", "Fossilunghia ", "Helixfossile ", "Domofossile ", "Ambra Antica ", "Fossilscudo ", "Fossilcranio ", "Osso Raro ", "Pietrabrillo ", "Neropietra ", "Pietralbore ", "Pietraovale ", "Roccianima ", "Grigiosfera* ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "??? ", "Adamasfera ", "Splendisfera ", "Messaggio Erba ", "Messaggio Fiamma ", "Messaggio Bolla ", "Messaggio Petalo ", "Messaggio Tunnel ", "Messaggio Lega ", "Messaggio Cuore ", "Messaggio Neve ", "Messaggio Spazio ", "Messaggio Aereo ", "Messaggio Iride ", "Messaggio Muro ", "Baccaliegia ", "Baccastagna ", "Baccapesca ", "Baccafrago ", "Baccaperina ", "Baccamela ", "Baccarancia ", "Baccaki ", "Baccaprugna ", "Baccacedro ", "Baccafico ", "Baccakiwi ", "Baccamango ", "Baccaguava ", "Baccapaia ", "Baccalampon ", "Baccamora ", "Baccabana ", "Baccapera ", "Baccananas ", "Baccagrana ", "Baccalga ", "Baccaloquat ", "Baccamelon ", "Baccauva ", "Baccamodoro ", "Baccavena ", "Baccagostan ", "Baccambutan ", "Baccalemon ", "Baccamelos ", "Baccapalma ", "Baccacomero ", "Baccadurian ", "Baccartillo ", "Baccacao ", "Baccapasflo ", "Baccaparmen ", "Baccarindo ", "Baccamoya ", "Baccarosmel ", "Baccakebia ", "Baccanaca ", "Baccababa ", "Baccapayapa ", "Baccaitan ", "Baccaciofo ", "Baccacitrus ", "Baccahaban ", "Baccaxan ", "Baccababiri ", "Baccacinlan ", "Baccalici ", "Baccalongan ", "Baccasalak ", "Baccapitaya ", "Baccacocca ", "Baccalangsa ", "Baccambola ", "Baccaenigma ", "Baccaracolo ", "Baccacrela ", "Baccajaba ", "Baccaroam ", "Luminpolvere ", "Erbachiara ", "Crescicappa ", "Condiv. Esp. ", "Rapidartigli ", "Calmanella ", "Mentalerba ", "Bendascelta ", "Roccia di Re ", "Argenpolvere ", "Monetamuleto ", "Velopuro ", "Cuorugiada ", "Dente Abissi ", "Squamabissi ", "Palla Fumo ", "Pietrastante ", "Bandana ", "Fortunuovo ", "Mirino ", "Metalcoperta ", "Avanzi ", "Squama Drago ", "Elettropalla ", "Sabbia Soffice ", "Pietradura ", "Miracolseme ", "Occhialineri ", "Cinturanera ", "Calamita ", "Acqua Magica ", "Beccaffilato ", "Velenaculeo ", "Gelomai ", "Spettrotarga ", "Cucchiaio Torto ", "Carbonella ", "Dentedidrago ", "Sciarpa Seta ", "Upgrade ", "Conchinella ", "Marearoma ", "Distraroma ", "Fortunpugno ", "Metalpolvere ", "Ossospesso ", "Gambo ", "Fascia Rossa ", "Fascia Blu ", "Fascia Rosa ", "Fascia Verde ", "Fascia Gialla ", "Grandelente ", "Muscolbanda ", "Saviocchiali ", "Abilcintura ", "Creta Luce ", "Assorbisfera ", "Vigorerba ", "Tossicsfera ", "Fiammosfera ", "Velopolvere ", "Focalnastro ", "Zoomlente ", "Metronomo ", "Ferropalla ", "Rallentocoda ", "Destincomune ", "Fangopece ", "Rocciafredda ", "Roccialiscia ", "Rocciacalda ", "Rocciaumida ", "Presartigli ", "Stolascelta ", "Vischiopunta ", "Vigorcerchio ", "Vigorfascia ", "Vigorlente ", "Vigorbanda ", "Vigorgliera ", "Vigorpeso ", "Disfoguscio ", "Granradice ", "Lentiscelta ", "Lastrarogo ", "Lastraidro ", "Lastrasaetta ", "Lastraprato ", "Lastragelo ", "Lastrapugno ", "Lastrafiele ", "Lastrageo ", "Lastracielo ", "Lastramente ", "Lastrabaco ", "Lastrapietra ", "Lastratimore ", "Lastradrakon ", "Lastratetra ", "Lastraferro ", "Bizzoaroma ", "Roccioaroma ", "Gonfioaroma ", "Ondaroma ", "Rosaroma ", "Fortunaroma ", "Puroaroma ", "Copertura ", "Elettritore ", "Magmatore ", "Dubbiodisco ", "Terrorpanno ", "Affilartigli ", "Affilodente ", "MT01 ", "MT02 ", "MT03 ", "MT04 ", "MT05 ", "MT06 ", "MT07 ", "MT08 ", "MT09 ", "MT10 ", "MT11 ", "MT12 ", "MT13 ", "MT14 ", "MT15 ", "MT16 ", "MT17 ", "MT18 ", "MT19 ", "MT20 ", "MT21 ", "MT22 ", "MT23 ", "MT24 ", "MT25 ", "MT26 ", "MT27 ", "MT28 ", "MT29 ", "MT30 ", "MT31 ", "MT32 ", "MT33 ", "MT34 ", "MT35 ", "MT36 ", "MT37 ", "MT38 ", "MT39 ", "MT40 ", "MT41 ", "MT42 ", "MT43 ", "MT44 ", "MT45 ", "MT46 ", "MT47 ", "MT48 ", "MT49 ", "MT50 ", "MT51 ", "MT52 ", "MT53 ", "MT54 ", "MT55 ", "MT56 ", "MT57 ", "MT58 ", "MT59 ", "MT60 ", "MT61 ", "MT62 ", "MT63 ", "MT64 ", "MT65 ", "MT66 ", "MT67 ", "MT68 ", "MT69 ", "MT70 ", "MT71 ", "MT72 ", "MT73 ", "MT74 ", "MT75 ", "MT76 ", "MT77 ", "MT78 ", "MT79 ", "MT80 ", "MT81 ", "MT82 ", "MT83 ", "MT84 ", "MT85 ", "MT86 ", "MT87 ", "MT88 ", "MT89 ", "MT90 ", "MT91 ", "MT92 ", "MN01 ", "MN02 ", "MN03 ", "MN04 ", "MN05 ", "MN06 ", "MN07 ", "MN08 ", "Esplorokit ", "Bottinosacca ", "Libro Regole ", "Poké Radar ", "Scheda Punti ", "Agenda ", "Portabolli ", "Scatola Chic ", "Bollosacca ", "Blocco Amici ", "Turbinchiave ", "Arcamuleto ", "Galachiave ", "Rossocatena ", "Mappa Città ", "Cercasfide ", "Salvadanaio ", "Amo Vecchio ", "Amo Buono ", "Super Amo ", "Sprayduck ", "Portapoffin ", "Bicicletta ", "Chiave Suite ", "Lettera di Oak ", "Ala Lunare ", "Scheda Soci ", "Flauto Cielo ", "Biglietto Nave ", "Tessera Gare ", "Magmapietra ", "Pacco ", "Coupon 1 ", "Coupon 2 ", "Coupon 3", "Depochiave", "Poz. Segreta"})
        Me.cmbItem.Location = New System.Drawing.Point(114, 63)
        Me.cmbItem.Name = "cmbItem"
        Me.cmbItem.Size = New System.Drawing.Size(158, 21)
        Me.cmbItem.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(6, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Strumento ricevuto:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmbPKMN2
        '
        Me.cmbPKMN2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbPKMN2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbPKMN2.FormattingEnabled = True
        Me.cmbPKMN2.Items.AddRange(New Object() {"???????????", "Bulbasaur", "Ivysaur", "Venusaur", "Charmander", "Charmeleon", "Charizard", "Squirtle", "Wartortle", "Blastoise", "Caterpie", "Metapod", "Butterfree", "Weedle", "Kakuna", "Beedrill", "Pidgey", "Pidgeotto", "Pidgeot", "Rattata", "Raticate", "Spearow", "Fearow", "Ekans", "Arbok", "Pikachu", "Raichu", "Sandshrew", "Sandslash", "Nidoran♀", "Nidorina", "Nidoqueen", "Nidoran♂", "Nidorino", "Nidoking", "Clefairy", "Clefable", "Vulpix", "Ninetales", "Jigglypuff", "Wigglytuff", "Zubat", "Golbat", "Oddish", "Gloom", "Vileplume", "Paras", "Parasect", "Venonat", "Venomoth", "Diglett", "Dugtrio", "Meowth", "Persian", "Psyduck", "Golduck", "Mankey", "Primeape", "Growlithe", "Arcanine", "Poliwag", "Poliwhirl", "Poliwrath", "Abra", "Kadabra", "Alakazam", "Machop", "Machoke", "Machamp", "Bellsprout", "Weepinbell", "Victreebel", "Tentacool", "Tentacruel", "Geodude", "Graveler", "Golem", "Ponyta", "Rapidash", "Slowpoke", "Slowbro", "Magnemite", "Magneton", "Farfetch'd", "Doduo", "Dodrio", "Seel", "Dewgong", "Grimer", "Muk", "Shellder", "Cloyster", "Gastly", "Haunter", "Gengar", "Onix", "Drowzee", "Hypno", "Krabby", "Kingler", "Voltorb", "Electrode", "Exeggcute", "Exeggutor", "Cubone", "Marowak", "Hitmonlee", "Hitmonchan", "Lickitung", "Koffing", "Weezing", "Rhyhorn", "Rhydon", "Chansey", "Tangela", "Kangaskhan", "Horsea", "Seadra", "Goldeen", "Seaking", "Staryu", "Starmie", "Mr. Mime", "Scyther", "Jynx", "Electabuzz", "Magmar", "Pinsir", "Tauros", "Magikarp", "Gyarados", "Lapras", "Ditto", "Eevee", "Vaporeon", "Jolteon", "Flareon", "Porygon", "Omanyte", "Omastar", "Kabuto", "Kabutops", "Aerodactyl", "Snorlax", "Articuno", "Zapdos", "Moltres", "Dratini", "Dragonair", "Dragonite", "Mewtwo", "Mew", "Chikorita", "Bayleef", "Meganium", "Cyndaquil", "Quilava", "Typhlosion", "Totodile", "Croconaw", "Feraligatr", "Sentret", "Furret", "Hoothoot", "Noctowl", "Ledyba", "Ledian", "Spinarak", "Ariados", "Crobat", "Chinchou", "Lanturn", "Pichu", "Cleffa", "Igglybuff", "Togepi", "Togetic", "Natu", "Xatu", "Mareep", "Flaaffy", "Ampharos", "Bellossom", "Marill", "Azumarill", "Sudowoodo", "Politoed", "Hoppip", "Skiploom", "Jumpluff", "Aipom", "Sunkern", "Sunflora", "Yanma", "Wooper", "Quagsire", "Espeon", "Umbreon", "Murkrow", "Slowking", "Misdreavus", "Unown", "Wobbuffet", "Girafarig", "Pineco", "Forretress", "Dunsparce", "Gligar", "Steelix", "Snubbull", "Granbull", "Qwilfish", "Scizor", "Shuckle", "Heracross", "Sneasel", "Teddiursa", "Ursaring", "Slugma", "Magcargo", "Swinub", "Piloswine", "Corsola", "Remoraid", "Octillery", "Delibird", "Mantine", "Skarmory", "Houndour", "Houndoom", "Kingdra", "Phanpy", "Donphan", "Porygon2", "Stantler", "Smeargle", "Tyrogue", "Hitmontop", "Smoochum", "Elekid", "Magby", "Miltank", "Blissey", "Raikou", "Entei", "Suicune", "Larvitar", "Pupitar", "Tyranitar", "Lugia", "Ho-Oh", "Celebi", "Treecko", "Grovyle", "Sceptile", "Torchic", "Combusken", "Blaziken", "Mudkip", "Marshtomp", "Swampert", "Poochyena", "Mightyena", "Zigzagoon", "Linoone", "Wurmple", "Silcoon", "Beautifly", "Cascoon", "Dustox", "Lotad", "Lombre", "Ludicolo", "Seedot", "Nuzleaf", "Shiftry", "Taillow", "Swellow", "Wingull", "Pelipper", "Ralts", "Kirlia", "Gardevoir", "Surskit", "Masquerain", "Shroomish", "Breloom", "Slakoth", "Vigoroth", "Slaking", "Nincada", "Ninjask", "Shedinja", "Whismur", "Loudred", "Exploud", "Makuhita", "Hariyama", "Azurill", "Nosepass", "Skitty", "Delcatty", "Sableye", "Mawile", "Aron", "Lairon", "Aggron", "Meditite", "Medicham", "Electrike", "Manectric", "Plusle", "Minun", "Volbeat", "Illumise", "Roselia", "Gulpin", "Swalot", "Carvanha", "Sharpedo", "Wailmer", "Wailord", "Numel", "Camerupt", "Torkoal", "Spoink", "Grumpig", "Spinda", "Trapinch", "Vibrava", "Flygon", "Cacnea", "Cacturne", "Swablu", "Altaria", "Zangoose", "Seviper", "Lunatone", "Solrock", "Barboach", "Whiscash", "Corphish", "Crawdaunt", "Baltoy", "Claydol", "Lileep", "Cradily", "Anorith", "Armaldo", "Feebas", "Milotic", "Castform", "Kecleon", "Shuppet", "Banette", "Duskull", "Dusclops", "Tropius", "Chimecho", "Absol", "Wynaut", "Snorunt", "Glalie", "Spheal", "Sealeo", "Walrein", "Clamperl", "Huntail", "Gorebyss", "Relicanth", "Luvdisc", "Bagon", "Shelgon", "Salamence", "Beldum", "Metang", "Metagross", "Regirock", "Regice", "Registeel", "Latias", "Latios", "Kyogre", "Groudon", "Rayquaza", "Jirachi", "Deoxys", "Turtwig", "Grotle", "Torterra", "Chimchar", "Monferno", "Infernape", "Piplup", "Prinplup", "Empoleon", "Starly", "Staravia", "Staraptor", "Bidoof", "Bibarel", "Kricketot", "Kricketune", "Shinx", "Luxio", "Luxray", "Budew", "Roserade", "Cranidos", "Rampardos", "Shieldon", "Bastiodon", "Burmy", "Wormadam", "Mothim", "Combee", "Vespiquen", "Pachirisu", "Buizel", "Floatzel", "Cherubi", "Cherrim", "Shellos", "Gastrodon", "Ambipom", "Drifloon", "Drifblim", "Buneary", "Lopunny", "Mismagius", "Honchkrow", "Glameow", "Purugly", "Chingling", "Stunky", "Skuntank", "Bronzor", "Bronzong", "Bonsly", "Mime Jr.", "Happiny", "Chatot", "Spiritomb", "Gible", "Gabite", "Garchomp", "Munchlax", "Riolu", "Lucario", "Hippopotas", "Hippowdon", "Skorupi", "Drapion", "Croagunk", "Toxicroak", "Carnivine", "Finneon", "Lumineon", "Mantyke", "Snover", "Abomasnow", "Weavile", "Magnezone", "Lickilicky", "Rhyperior", "Tangrowth", "Electivire", "Magmortar", "Togekiss", "Yanmega", "Leafeon", "Glaceon", "Gliscor", "Mamoswine", "Porygon-Z", "Gallade", "Probopass", "Dusknoir", "Froslass", "Rotom", "Uxie", "Mesprit", "Azelf", "Dialga", "Palkia", "Heatran", "Regigigas", "Giratina", "Cresselia", "Phione", "Manaphy", "Darkrai", "Shaymin", "Arceus"})
        Me.cmbPKMN2.Location = New System.Drawing.Point(114, 41)
        Me.cmbPKMN2.Name = "cmbPKMN2"
        Me.cmbPKMN2.Size = New System.Drawing.Size(158, 21)
        Me.cmbPKMN2.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(6, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Pokemon ricevuto:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmbPKMN1
        '
        Me.cmbPKMN1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbPKMN1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbPKMN1.FormattingEnabled = True
        Me.cmbPKMN1.Items.AddRange(New Object() {"???????????", "Bulbasaur", "Ivysaur", "Venusaur", "Charmander", "Charmeleon", "Charizard", "Squirtle", "Wartortle", "Blastoise", "Caterpie", "Metapod", "Butterfree", "Weedle", "Kakuna", "Beedrill", "Pidgey", "Pidgeotto", "Pidgeot", "Rattata", "Raticate", "Spearow", "Fearow", "Ekans", "Arbok", "Pikachu", "Raichu", "Sandshrew", "Sandslash", "Nidoran♀", "Nidorina", "Nidoqueen", "Nidoran♂", "Nidorino", "Nidoking", "Clefairy", "Clefable", "Vulpix", "Ninetales", "Jigglypuff", "Wigglytuff", "Zubat", "Golbat", "Oddish", "Gloom", "Vileplume", "Paras", "Parasect", "Venonat", "Venomoth", "Diglett", "Dugtrio", "Meowth", "Persian", "Psyduck", "Golduck", "Mankey", "Primeape", "Growlithe", "Arcanine", "Poliwag", "Poliwhirl", "Poliwrath", "Abra", "Kadabra", "Alakazam", "Machop", "Machoke", "Machamp", "Bellsprout", "Weepinbell", "Victreebel", "Tentacool", "Tentacruel", "Geodude", "Graveler", "Golem", "Ponyta", "Rapidash", "Slowpoke", "Slowbro", "Magnemite", "Magneton", "Farfetch'd", "Doduo", "Dodrio", "Seel", "Dewgong", "Grimer", "Muk", "Shellder", "Cloyster", "Gastly", "Haunter", "Gengar", "Onix", "Drowzee", "Hypno", "Krabby", "Kingler", "Voltorb", "Electrode", "Exeggcute", "Exeggutor", "Cubone", "Marowak", "Hitmonlee", "Hitmonchan", "Lickitung", "Koffing", "Weezing", "Rhyhorn", "Rhydon", "Chansey", "Tangela", "Kangaskhan", "Horsea", "Seadra", "Goldeen", "Seaking", "Staryu", "Starmie", "Mr. Mime", "Scyther", "Jynx", "Electabuzz", "Magmar", "Pinsir", "Tauros", "Magikarp", "Gyarados", "Lapras", "Ditto", "Eevee", "Vaporeon", "Jolteon", "Flareon", "Porygon", "Omanyte", "Omastar", "Kabuto", "Kabutops", "Aerodactyl", "Snorlax", "Articuno", "Zapdos", "Moltres", "Dratini", "Dragonair", "Dragonite", "Mewtwo", "Mew", "Chikorita", "Bayleef", "Meganium", "Cyndaquil", "Quilava", "Typhlosion", "Totodile", "Croconaw", "Feraligatr", "Sentret", "Furret", "Hoothoot", "Noctowl", "Ledyba", "Ledian", "Spinarak", "Ariados", "Crobat", "Chinchou", "Lanturn", "Pichu", "Cleffa", "Igglybuff", "Togepi", "Togetic", "Natu", "Xatu", "Mareep", "Flaaffy", "Ampharos", "Bellossom", "Marill", "Azumarill", "Sudowoodo", "Politoed", "Hoppip", "Skiploom", "Jumpluff", "Aipom", "Sunkern", "Sunflora", "Yanma", "Wooper", "Quagsire", "Espeon", "Umbreon", "Murkrow", "Slowking", "Misdreavus", "Unown", "Wobbuffet", "Girafarig", "Pineco", "Forretress", "Dunsparce", "Gligar", "Steelix", "Snubbull", "Granbull", "Qwilfish", "Scizor", "Shuckle", "Heracross", "Sneasel", "Teddiursa", "Ursaring", "Slugma", "Magcargo", "Swinub", "Piloswine", "Corsola", "Remoraid", "Octillery", "Delibird", "Mantine", "Skarmory", "Houndour", "Houndoom", "Kingdra", "Phanpy", "Donphan", "Porygon2", "Stantler", "Smeargle", "Tyrogue", "Hitmontop", "Smoochum", "Elekid", "Magby", "Miltank", "Blissey", "Raikou", "Entei", "Suicune", "Larvitar", "Pupitar", "Tyranitar", "Lugia", "Ho-Oh", "Celebi", "Treecko", "Grovyle", "Sceptile", "Torchic", "Combusken", "Blaziken", "Mudkip", "Marshtomp", "Swampert", "Poochyena", "Mightyena", "Zigzagoon", "Linoone", "Wurmple", "Silcoon", "Beautifly", "Cascoon", "Dustox", "Lotad", "Lombre", "Ludicolo", "Seedot", "Nuzleaf", "Shiftry", "Taillow", "Swellow", "Wingull", "Pelipper", "Ralts", "Kirlia", "Gardevoir", "Surskit", "Masquerain", "Shroomish", "Breloom", "Slakoth", "Vigoroth", "Slaking", "Nincada", "Ninjask", "Shedinja", "Whismur", "Loudred", "Exploud", "Makuhita", "Hariyama", "Azurill", "Nosepass", "Skitty", "Delcatty", "Sableye", "Mawile", "Aron", "Lairon", "Aggron", "Meditite", "Medicham", "Electrike", "Manectric", "Plusle", "Minun", "Volbeat", "Illumise", "Roselia", "Gulpin", "Swalot", "Carvanha", "Sharpedo", "Wailmer", "Wailord", "Numel", "Camerupt", "Torkoal", "Spoink", "Grumpig", "Spinda", "Trapinch", "Vibrava", "Flygon", "Cacnea", "Cacturne", "Swablu", "Altaria", "Zangoose", "Seviper", "Lunatone", "Solrock", "Barboach", "Whiscash", "Corphish", "Crawdaunt", "Baltoy", "Claydol", "Lileep", "Cradily", "Anorith", "Armaldo", "Feebas", "Milotic", "Castform", "Kecleon", "Shuppet", "Banette", "Duskull", "Dusclops", "Tropius", "Chimecho", "Absol", "Wynaut", "Snorunt", "Glalie", "Spheal", "Sealeo", "Walrein", "Clamperl", "Huntail", "Gorebyss", "Relicanth", "Luvdisc", "Bagon", "Shelgon", "Salamence", "Beldum", "Metang", "Metagross", "Regirock", "Regice", "Registeel", "Latias", "Latios", "Kyogre", "Groudon", "Rayquaza", "Jirachi", "Deoxys", "Turtwig", "Grotle", "Torterra", "Chimchar", "Monferno", "Infernape", "Piplup", "Prinplup", "Empoleon", "Starly", "Staravia", "Staraptor", "Bidoof", "Bibarel", "Kricketot", "Kricketune", "Shinx", "Luxio", "Luxray", "Budew", "Roserade", "Cranidos", "Rampardos", "Shieldon", "Bastiodon", "Burmy", "Wormadam", "Mothim", "Combee", "Vespiquen", "Pachirisu", "Buizel", "Floatzel", "Cherubi", "Cherrim", "Shellos", "Gastrodon", "Ambipom", "Drifloon", "Drifblim", "Buneary", "Lopunny", "Mismagius", "Honchkrow", "Glameow", "Purugly", "Chingling", "Stunky", "Skuntank", "Bronzor", "Bronzong", "Bonsly", "Mime Jr.", "Happiny", "Chatot", "Spiritomb", "Gible", "Gabite", "Garchomp", "Munchlax", "Riolu", "Lucario", "Hippopotas", "Hippowdon", "Skorupi", "Drapion", "Croagunk", "Toxicroak", "Carnivine", "Finneon", "Lumineon", "Mantyke", "Snover", "Abomasnow", "Weavile", "Magnezone", "Lickilicky", "Rhyperior", "Tangrowth", "Electivire", "Magmortar", "Togekiss", "Yanmega", "Leafeon", "Glaceon", "Gliscor", "Mamoswine", "Porygon-Z", "Gallade", "Probopass", "Dusknoir", "Froslass", "Rotom", "Uxie", "Mesprit", "Azelf", "Dialga", "Palkia", "Heatran", "Regigigas", "Giratina", "Cresselia", "Phione", "Manaphy", "Darkrai", "Shaymin", "Arceus"})
        Me.cmbPKMN1.Location = New System.Drawing.Point(114, 19)
        Me.cmbPKMN1.Name = "cmbPKMN1"
        Me.cmbPKMN1.Size = New System.Drawing.Size(158, 21)
        Me.cmbPKMN1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(6, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pokemon richiesto:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label4.Location = New System.Drawing.Point(65, 336)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(251, 15)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Copyright © 2012 JackHack96  Matteo Iervasi"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 27)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(0, 3, 3, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(401, 129)
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(395, 362)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.mnuMain)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuMain
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DS Trade Editor"
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApriROMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EsciToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AiutoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InformazioniToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dlgOpen As System.Windows.Forms.OpenFileDialog
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Percorso226 As System.Windows.Forms.RadioButton
    Friend WithEvents Nevepoli As System.Windows.Forms.RadioButton
    Friend WithEvents Evopoli As System.Windows.Forms.RadioButton
    Friend WithEvents Mineropoli As System.Windows.Forms.RadioButton
    Friend WithEvents SalvaROMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbPKMN1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbItem As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbPKMN2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents LinguaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItalianoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IngleseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class

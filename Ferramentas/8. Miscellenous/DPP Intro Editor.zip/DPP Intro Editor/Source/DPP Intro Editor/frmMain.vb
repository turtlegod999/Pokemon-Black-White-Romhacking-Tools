﻿Public Class frmMain
    Dim PercorsoROM As String
    Dim ROMAperta As Boolean
    Private Sub cmdApri_Click(sender As System.Object, e As System.EventArgs) Handles cmdApri.Click
        NomeROM = ""
        CodiceROM = ""
        dlgOpen.Title = "Apri ROM..."
        dlgOpen.Filter = "File NDS (*.nds)|*.nds"
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            If (SupportedROM(dlgOpen.FileName) = True) Then
                Me.Text = "DPP Intro Editor - " & NomeROM
                PercorsoROM = dlgOpen.FileName
                ROMAperta = True
                LoadData()
            Else
                MsgBox("ROM non supportata!", vbExclamation, "DPP Intro Editor")
            End If
        End If
    End Sub
    Private Sub LoadData()
        If (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAE" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAE") Then
            LoadThis(2798128, PercorsoROM, cmbPKMN)
            LoadThis(2796812, PercorsoROM, cmbSuono)
        ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAI" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAI") Then
            LoadThis(2799184, PercorsoROM, cmbPKMN)
            LoadThis(2797868, PercorsoROM, cmbSuono)
        ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUI") Then
            LoadThis(3439956, PercorsoROM, cmbPKMN)
            LoadThis(3441544, PercorsoROM, cmbSuono)
        ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUE") Then
            LoadThis(3440468, PercorsoROM, cmbPKMN)
            LoadThis(3442056, PercorsoROM, cmbSuono)
        End If
    End Sub

    Private Sub cmdSalva_Click(sender As System.Object, e As System.EventArgs) Handles cmdSalva.Click
        If (ROMAperta = True) Then
            If (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAE" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAE") Then
                WriteThis(2796812, PercorsoROM, cmbSuono)
                WriteThis(2798128, PercorsoROM, cmbPKMN)
            ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAI" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAI") Then
                WriteThis(2797868, PercorsoROM, cmbSuono)
                WriteThis(2799184, PercorsoROM, cmbPKMN)
            ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUI") Then
                WriteThis(3441544, PercorsoROM, cmbSuono)
                WriteThis(3439956, PercorsoROM, cmbPKMN)
            ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUE") Then
                WriteThis(3442056, PercorsoROM, cmbSuono)
                WriteThis(3440468, PercorsoROM, cmbPKMN)
            End If
            MsgBox("Dati salvati! =)", vbInformation, "DPP Intro Editor")
        Else
            MsgBox("Non è aperta nessuna ROM!", vbExclamation, "Errore")
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If (CheckBox1.CheckState = CheckState.Checked) Then
            cmbSuono.Enabled = True
        Else
            cmbSuono.Enabled = False
        End If
    End Sub

    Private Sub cmbPKMN_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cmbPKMN.SelectedIndexChanged
        If (CheckBox1.CheckState = CheckState.Unchecked) Then
            cmbSuono.SelectedIndex = cmbPKMN.SelectedIndex
        End If
    End Sub
End Class

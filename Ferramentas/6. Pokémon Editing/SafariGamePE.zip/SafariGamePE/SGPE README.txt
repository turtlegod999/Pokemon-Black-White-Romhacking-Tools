  _____  _____ _____  ______ 
 / ____|/ ____|  __ \|  ____|
| (___ | |  __| |__) | |__   
 \___ \| | |_ |  ___/|  __|  
 ____) | |__| | |    | |____ 
|_____/ \_____|_|    |______|
                             
Safari Game Pok�mon Editor v1.0

	 Programmed by D-Trogh

HowTo:
- Dump the encdata_ex.narc with NitroExplorer
	[You'll find the NARC in \arc]
- Open SGPE, select the NARC file
- Edit the Pok�mon using SGPE and save
- Import the NARC back with NitroExplorer
- Done =D

NOTE:
Never remove or edit this README!
When sharing this tool, always include this
README!
 _    _ _______ _____  ______ 
| |  | |__   __|  __ \|  ____|
| |__| |  | |  | |__) | |__   
|  __  |  | |  |  ___/|  __|  
| |  | |  | |  | |    | |____ 
|_|  |_|  |_|  |_|    |______|
                              
Honey Tree Pok�mon Editor v1.0

	 Programmed by D-Trogh

HowTo:
- Dump the encdata_ex.narc with NitroExplorer
	[You'll find the NARC in \arc]
- Open HTPE and select your game (D or P)
- Edit the Pok�mon using HTPE and save
- Import the NARC back with NitroExplorer
- Done =D

NOTE:
Never remove or edit this README!
When sharing this tool, always include this
README!
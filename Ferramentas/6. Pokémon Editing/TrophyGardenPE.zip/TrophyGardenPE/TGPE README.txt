 _______ _____ _____  ______ 
|__   __/ ____|  __ \|  ____|
   | | | |  __| |__) | |__   
   | | | | |_ |  ___/|  __|  
   | | | |__| | |    | |____ 
   |_|  \_____|_|    |______|
                             
Tropy Garden Pok�mon Editor v1.0

	 Programmed by D-Trogh

HowTo:
- Dump the encdata_ex.narc with NitroExplorer
	[You'll find the NARC in \arc]
- Open TGPE, select the NARC file
- Edit the Pok�mon using TGPE and save
- Import the NARC back with NitroExplorer
- Done =D

NOTE:
Never remove or edit this README!
When sharing this tool, always include this
README!
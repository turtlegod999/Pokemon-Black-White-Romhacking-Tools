﻿Public Class frmMain
    Dim PercorsoROM As String
    Dim ROMAperta As Boolean
    Private Sub ApriROMToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ApriROMToolStripMenuItem.Click
        NomeROM = ""
        CodiceROM = ""
        dlgOpen.Title = "Apri ROM..."
        dlgOpen.Filter = "File NDS (*.nds)|*.nds"
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            If (SupportedROM(dlgOpen.FileName) = True) Then
                Me.Text = "DPP Starter - " & NomeROM
                PercorsoROM = dlgOpen.FileName
                ROMAperta = True
                LoadData()
            Else
                MsgBox("ROM non supportata!", vbExclamation, "DPP Starter")
            End If
        End If
    End Sub
    Private Sub LoadData()
        If (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAE" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAE") Then
            LoadThis(2855304, PercorsoROM, StarterA)
            LoadThis(2855308, PercorsoROM, StarterB)
            LoadThis(2855312, PercorsoROM, StarterC)
        ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAI" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAI") Then
            LoadThis(2848540, PercorsoROM, StarterA)
            LoadThis(2848544, PercorsoROM, StarterB)
            LoadThis(2848548, PercorsoROM, StarterC)
        ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUI") Then
            LoadThis(3508160, PercorsoROM, StarterA)
            LoadThis(3508164, PercorsoROM, StarterB)
            LoadThis(3508168, PercorsoROM, StarterC)
        ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUE") Then
            LoadThis(3508672, PercorsoROM, StarterA)
            LoadThis(3508676, PercorsoROM, StarterB)
            LoadThis(3508680, PercorsoROM, StarterC)
        End If
    End Sub

    Private Sub SalvaROMToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalvaROMToolStripMenuItem.Click
        If (ROMAperta = True) Then
            If (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAE" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAE") Then
                WriteThis(2855304, PercorsoROM, StarterA)
                WriteThis(2847724, PercorsoROM, StarterA)
                WriteThis(2855308, PercorsoROM, StarterB)
                WriteThis(2847728, PercorsoROM, StarterB)
                WriteThis(2855312, PercorsoROM, StarterC)
                WriteThis(2847732, PercorsoROM, StarterC)
            ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAI" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAI") Then
                WriteThis(2848540, PercorsoROM, StarterA)
                WriteThis(2855816, PercorsoROM, StarterA)
                WriteThis(2848544, PercorsoROM, StarterB)
                WriteThis(2855820, PercorsoROM, StarterB)
                WriteThis(2848548, PercorsoROM, StarterC)
                WriteThis(2855824, PercorsoROM, StarterC)
            ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUI") Then
                WriteThis(3508160, PercorsoROM, StarterA)
                WriteThis(3508164, PercorsoROM, StarterB)
                WriteThis(3508168, PercorsoROM, StarterC)
            ElseIf (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUE") Then
                WriteThis(3508672, PercorsoROM, StarterA)
                WriteThis(3508676, PercorsoROM, StarterB)
                WriteThis(3508680, PercorsoROM, StarterC)
            End If
            MsgBox("Dati salvati! =)", vbInformation, "DPP Intro Editor")
        Else
            MsgBox("Non è aperta nessuna ROM!", vbExclamation, "Errore")
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        StarterA.SelectedIndex = 387
        StarterB.SelectedIndex = 390
        StarterC.SelectedIndex = 393
    End Sub

    Private Sub InfoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InfoToolStripMenuItem.Click
        frmAbout.Show()
    End Sub

    Private Sub EsciToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles EsciToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class

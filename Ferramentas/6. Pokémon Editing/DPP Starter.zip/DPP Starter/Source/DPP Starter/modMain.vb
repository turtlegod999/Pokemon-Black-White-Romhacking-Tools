﻿Module modMain
    Public NomeROM, CodiceROM As String
    Public Function SupportedROM(ByVal PathROM As String) As Boolean
        Dim ROMFile As New IO.FileStream(PathROM, IO.FileMode.Open, IO.FileAccess.Read)
        Dim bNomeROM(12), bCodiceROM(4) As Byte
        ROMFile.Read(bNomeROM, 0, 12)
        ROMFile.Read(bCodiceROM, 0, 4)
        Dim i As Integer
        For i = 0 To 11
            NomeROM = NomeROM & ChrW(bNomeROM(i))
        Next
        For i = 0 To 3
            CodiceROM = CodiceROM & ChrW(bCodiceROM(i))
        Next
        If (Microsoft.VisualBasic.Left(NomeROM, 10) = "POKEMON PL") Then
            If (Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUE" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "CPUI") Then
                SupportedROM = True
            End If
        ElseIf (Microsoft.VisualBasic.Left(NomeROM, 9) = "POKEMON D") Then
            If (Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAI" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "ADAE") Then
                SupportedROM = True
            End If
        ElseIf (Microsoft.VisualBasic.Left(NomeROM, 9) = "POKEMON P") Then
            If (Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAI" Or Microsoft.VisualBasic.Left(CodiceROM, 4) = "APAE") Then
                SupportedROM = True
            End If
        Else
            SupportedROM = False
        End If
        ROMFile.Close()
    End Function
    Public Sub WriteThis(Offset As Integer, ROMPath As String, List As ComboBox)
        Dim ROMFile As New IO.FileStream(ROMPath, IO.FileMode.Open, IO.FileAccess.Write)
        Dim writer As New IO.BinaryWriter(ROMFile)
        writer.BaseStream.Seek(Offset, IO.SeekOrigin.Begin)
        writer.Write(CUShort(List.SelectedIndex))
        writer.Close()
        ROMFile.Close()
    End Sub
    Public Sub LoadThis(Offset As Integer, ROMPath As String, List As ComboBox)
        Dim ROMFile As New IO.FileStream(ROMPath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim reader As New IO.BinaryReader(ROMFile), value As UShort
        reader.BaseStream.Seek(Offset, IO.SeekOrigin.Begin)
        value = reader.ReadUInt16()
        List.SelectedIndex = CInt(value)
        reader.Close()
        ROMFile.Close()
    End Sub
End Module

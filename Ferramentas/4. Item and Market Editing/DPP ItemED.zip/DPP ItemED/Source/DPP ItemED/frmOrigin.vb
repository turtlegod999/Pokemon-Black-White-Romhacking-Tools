﻿Imports System.Windows.Forms

Public Class frmOrigin

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If (Button1.Text = "Show help") Then
            Button1.Text = "Hide help"
            Me.Size = New Size(494, 244)
        Else
            Button1.Text = "Show help"
            Me.Size = New Size(168, 244)
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        If (RadioButton1.Checked = False And RadioButton2.Checked = False And RadioButton3.Checked = False And RadioButton4.Checked = False And RadioButton5.Checked = False And RadioButton6.Checked = False And RadioButton7.Checked = False And RadioButton8.Checked = False And RadioButton9.Checked = False And RadioButton10.Checked = False) Then
            If (frmMain.ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
                MsgBox("Non hai selezionato nulla!", vbExclamation, "Errore")
            Else
                MsgBox("You didn't select anything!", vbExclamation, "Error")
            End If
        Else
            If (RadioButton1.Checked = True) Then
                frmMain.ROMOrigin = RadioButton1.Text
            ElseIf (RadioButton2.Checked = True) Then
                frmMain.ROMOrigin = RadioButton2.Text
            ElseIf (RadioButton3.Checked = True) Then
                frmMain.ROMOrigin = RadioButton3.Text
            ElseIf (RadioButton4.Checked = True) Then
                frmMain.ROMOrigin = RadioButton4.Text
            ElseIf (RadioButton5.Checked = True) Then
                frmMain.ROMOrigin = RadioButton5.Text
            ElseIf (RadioButton6.Checked = True) Then
                frmMain.ROMOrigin = RadioButton6.Text
            ElseIf (RadioButton7.Checked = True) Then
                frmMain.ROMOrigin = RadioButton7.Text
            ElseIf (RadioButton8.Checked = True) Then
                frmMain.ROMOrigin = RadioButton8.Text
            ElseIf (RadioButton9.Checked = True) Then
                frmMain.ROMOrigin = RadioButton9.Text
            ElseIf (RadioButton10.Checked = True) Then
                frmMain.ROMOrigin = RadioButton10.Text
            End If
            Me.Close()
        End If
    End Sub
End Class

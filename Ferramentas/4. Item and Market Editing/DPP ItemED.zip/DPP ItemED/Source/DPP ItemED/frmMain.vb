﻿Imports System.IO
Imports System.Text

Public Class frmMain
    Dim PercorsoNARC, PercorsoMSG As String, filePrefix As String, PercorsoARM9 As String
    Public ROMOrigin As String
    Dim ROMAperta As Boolean
    Public isVar As Boolean = False
    Dim count As Integer = 0
    Dim MSG As NarcReader, NARC As NarcReader
    Private Sub ApriROMToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ApriROMToolStripMenuItem.Click
        If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
            dlgOpen.Title = "Apri NARC..."
            dlgOpen.Filter = "Archivio NARC (*.narc)|*item_data.narc"
        Else
            dlgOpen.Title = "Open NARC..."
            dlgOpen.Filter = "NARC Archive (*.narc)|*item_data.narc"
        End If
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            PercorsoNARC = dlgOpen.FileName
            ROMAperta = True
            EnableAll()
            If (dlgOpen.SafeFileName = "item_data.narc") Then
                filePrefix = "DP"
            ElseIf (dlgOpen.SafeFileName = "pl_item_data.narc") Then
                filePrefix = "P"
            ElseIf (dlgOpen.SafeFileName = "hgss_item_data.narc") Then
                filePrefix = "HGSS"
            End If
        Else
            Exit Sub
        End If
        dlgOpen.Reset()
        If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
            dlgOpen.Title = "Apri NARC..."
            dlgOpen.Filter = "Archivio NARC (*.narc)|*msg.narc"
        Else
            dlgOpen.Title = "Open NARC..."
            dlgOpen.Filter = "NARC Archive (*.narc)|*msg.narc"
        End If
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            PercorsoMSG = dlgOpen.FileName
        Else
            Exit Sub
        End If
        dlgOpen.Reset()
        If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
            dlgOpen.Title = "Apri ARM9..."
            dlgOpen.Filter = "File BIN (*.bin)|*arm9.bin"
        Else
            dlgOpen.Title = "Open ARM9..."
            dlgOpen.Filter = "BIN File (*.bin)|*arm9.bin"
        End If
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            PercorsoARM9 = dlgOpen.FileName
            MSG = New NarcReader(PercorsoMSG)
            NARC = New NarcReader(PercorsoNARC)
            frmOrigin.Show()
            LoadLists()
        Else
            Exit Sub
        End If
    End Sub
    Private Sub LoadLists()
        lstItems.Items.Clear()
        cmbAttack.Items.Clear()
        Dim MSGFile As New IO.FileStream(PercorsoMSG, IO.FileMode.Open, IO.FileAccess.Read), reader As New BinaryReader(MSGFile)
        If (filePrefix = "DP") Then
            reader.BaseStream.Seek(MSG.fe(345).Ofs, SeekOrigin.Begin)
            readText(reader, lstItems)
            reader.BaseStream.Seek(MSG.fe(589).Ofs, SeekOrigin.Begin)
            readText(reader, cmbAttack)
        ElseIf (filePrefix = "P") Then
            reader.BaseStream.Seek(MSG.fe(392).Ofs, SeekOrigin.Begin)
            readText(reader, lstItems)
            reader.BaseStream.Seek(MSG.fe(648).Ofs, SeekOrigin.Begin)
            readText(reader, cmbAttack)
        ElseIf (filePrefix = "HGSS") Then
            reader.BaseStream.Seek(MSG.fe(222).Ofs, SeekOrigin.Begin)
            readText(reader, lstItems)
            reader.BaseStream.Seek(MSG.fe(751).Ofs, SeekOrigin.Begin)
            readText(reader, cmbAttack)
        End If
        MSGFile.Close()
        reader.Close()
    End Sub
    Private Sub LoadData()
        Dim ROMFile As New FileStream(PercorsoNARC, FileMode.Open, FileAccess.Read), reader As New BinaryReader(ROMFile)
        reader.BaseStream.Seek(NARC.fe(lstItems.SelectedIndex).Ofs, SeekOrigin.Begin)
        txtPrice.Text = reader.ReadUInt16
        If (txtPS.Enabled = True) Then
            ROMFile.Seek(NARC.fe(lstItems.SelectedIndex).Ofs + 27, IO.SeekOrigin.Begin)
            txtPS.Text = reader.ReadByte
        End If
        If (txtPassi.Enabled = True) Then
            ROMFile.Seek(NARC.fe(lstItems.SelectedIndex).Ofs + 3, IO.SeekOrigin.Begin)
            txtPassi.Text = reader.ReadByte
        End If
        If (cmbAttack.Enabled = True) Then
            Dim ARM9File As New FileStream(PercorsoARM9, FileMode.Open, FileAccess.Read), ARMreader As New BinaryReader(ARM9File)
            Select Case ROMOrigin
                Case "ADAE", "APAE"
                    ARMreader.BaseStream.Seek(1017068 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    cmbAttack.SelectedIndex = ARMreader.ReadUInt16
                Case "ADAI", "APAI"
                    ARMreader.BaseStream.Seek(1016996 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    cmbAttack.SelectedIndex = ARMreader.ReadUInt16
                Case "CPUE"
                    ARMreader.BaseStream.Seek(986108 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    cmbAttack.SelectedIndex = ARMreader.ReadUInt16
                Case "CPUI"
                    ARMreader.BaseStream.Seek(986136 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    cmbAttack.SelectedIndex = ARMreader.ReadUInt16
                Case "IPKE", "IPGE"
                    ARMreader.BaseStream.Seek(1048780 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    cmbAttack.SelectedIndex = ARMreader.ReadUInt16
                Case "IPKI", "IPGI"
                    ARMreader.BaseStream.Seek(1048644 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    cmbAttack.SelectedIndex = ARMreader.ReadUInt16
            End Select
            ARM9File.Close()
            ARMreader.Close()
        End If
        ROMFile.Close()
        reader.Close()
    End Sub

    Private Sub WriteData()
        Dim ROMFile As New FileStream(PercorsoNARC, FileMode.Open, FileAccess.Write), writer As New BinaryWriter(ROMFile)
        writer.BaseStream.Seek(NARC.fe(lstItems.SelectedIndex).Ofs, SeekOrigin.Begin)
        writer.Write(Convert.ToInt16(txtPrice.Text))
        If (txtPS.Enabled = True) Then
            ROMFile.Seek(NARC.fe(lstItems.SelectedIndex).Ofs + 27, IO.SeekOrigin.Begin)
            writer.Write(Convert.ToInt16(txtPS.Text))
        End If
        If (txtPassi.Enabled = True) Then
            ROMFile.Seek(NARC.fe(lstItems.SelectedIndex).Ofs + 3, IO.SeekOrigin.Begin)
            writer.Write(Convert.ToInt16(txtPassi.Text))
        End If
        If (cmbAttack.Enabled = True) Then
            Dim ARM9File As New FileStream(PercorsoARM9, FileMode.Open, FileAccess.Write), ARMwriter As New BinaryWriter(ARM9File)
            Select Case ROMOrigin
                Case "ADAE", "APAE"
                    ARMwriter.BaseStream.Seek(1017068 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    ARMwriter.Write(Convert.ToInt16(cmbAttack.SelectedIndex))
                Case "ADAI", "APAI"
                    ARMwriter.BaseStream.Seek(1016996 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    ARMwriter.Write(Convert.ToInt16(cmbAttack.SelectedIndex))
                Case "CPUE"
                    ARMwriter.BaseStream.Seek(986108 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    ARMwriter.Write(Convert.ToInt16(cmbAttack.SelectedIndex))
                Case "CPUI"
                    ARMwriter.BaseStream.Seek(986136 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    ARMwriter.Write(Convert.ToInt16(cmbAttack.SelectedIndex))
                Case "IPKE", "IPGE"
                    ARMwriter.BaseStream.Seek(1048780 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    ARMwriter.Write(Convert.ToInt16(cmbAttack.SelectedIndex))
                Case "IPKI", "IPGI"
                    ARMwriter.BaseStream.Seek(1048644 + (2 * (lstItems.SelectedIndex - 328)), SeekOrigin.Begin)
                    ARMwriter.Write(Convert.ToInt16(cmbAttack.SelectedIndex))
            End Select
            ARM9File.Close()
            ARMwriter.Close()
        End If
        ROMFile.Close()
        writer.Close()
    End Sub

    Private Sub EsciToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles EsciToolStripMenuItem.Click
        If (ROMAperta = True) Then
            Dim risp As String
            risp = MsgBox("You've loaded a NARC. If you didn't save any changes, you'll lose them. Exit anyway?", vbYesNo, "NARC Loaded. Exit anyway?")
            If (risp = vbYes) Then
                Me.Close()
            End If
        Else
            Me.Close()
        End If
    End Sub

    Private Sub txtPrice_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtPrice.KeyPress
        If (Not IsNumeric(e.KeyChar)) And (Asc(e.KeyChar) <> 8) Then
            e.Handled = True
        End If
    End Sub

    Private Sub lstItems_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lstItems.SelectedIndexChanged
        Select Case lstItems.SelectedIndex
            Case 17, 25, 26, 30, 31, 32, 33, 155
                txtPS.Enabled = True
                txtPassi.Enabled = False
                cmbAttack.Enabled = False
            Case 76, 77, 79
                txtPassi.Enabled = True
                txtPS.Enabled = False
                cmbAttack.Enabled = False
            Case 328 To 419
                cmbAttack.Enabled = True
                txtPS.Enabled = False
                txtPassi.Enabled = False
            Case Else
                txtPS.Text = ""
                txtPS.Enabled = False
                txtPassi.Text = ""
                txtPassi.Enabled = False
                cmbAttack.Enabled = False
        End Select
        LoadData()
    End Sub

    Private Sub EnableAll()
        lstItems.Enabled = True
        txtPrice.Enabled = True
    End Sub

    Private Sub SalvaROMToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalvaROMToolStripMenuItem.Click
        If (ROMAperta = True) Then
            WriteData()
        End If
    End Sub

    Private Sub InformazioniToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InformazioniToolStripMenuItem.Click
        frmAbout.Show()
    End Sub

    Private Sub readText(reader As BinaryReader, ctrl As Control)
        Dim numTextFile As UShort
        Dim key As UInt32
        numTextFile = reader.ReadUInt16
        key = reader.ReadUInt16
        key = (key * &H2FD) And &HFFFF
        Dim textList As New List(Of TextStruct)()
        For i = 0 To numTextFile - 1
            Dim actualTextFile = New TextStruct
            actualTextFile.key2 = (key * (i + 1) And &HFFFF)
            actualTextFile.realKey = actualTextFile.key2 Or (actualTextFile.key2 << 16)
            actualTextFile.startOffset = reader.ReadInt32() Xor actualTextFile.realKey
            actualTextFile.size = reader.ReadInt32() Xor actualTextFile.realKey
            textList.Add(actualTextFile)
        Next
        For i = 0 To numTextFile - 1
            Dim actualTextFile = textList(i)
            key = (&H91BD3 * (i + 1)) And &HFFFF
            Dim str As New StringBuilder()
            isVar = False
            For k = 0 To actualTextFile.size - 1
                If (count = 4) Then
                    str.Append("] ")
                    isVar = False
                    count = 0
                End If
                Dim value = reader.ReadUInt16() Xor key
                Dim car = getCharacter(value)
                If (car = "[]") Then
                    str.Append(" [VAR ")
                    isVar = True
                Else
                    str.Append(car)
                End If
                If (isVar) Then count = count + 1
                key = key + &H493D
                key = key And &HFFFF
            Next
            actualTextFile.text = str.ToString
            If (TypeOf ctrl Is ListBox) Then
                lstItems.Items.Add(actualTextFile.text)
            ElseIf (TypeOf ctrl Is ComboBox) Then
                cmbAttack.Items.Add(actualTextFile.text)
            End If
            textList(i) = actualTextFile
        Next
    End Sub

    Public Structure TextStruct
        Public id As Integer
        Public startOffset As Integer
        Public text As [String]
        Public key2 As Integer
        Public realKey As Integer
        Public size As Integer
    End Structure
End Class

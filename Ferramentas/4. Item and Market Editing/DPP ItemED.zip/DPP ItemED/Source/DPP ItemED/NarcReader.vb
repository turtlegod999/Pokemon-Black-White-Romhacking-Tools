﻿Imports System.IO
Imports System.Runtime.InteropServices

<StructLayout(LayoutKind.Sequential)> _
Public Structure FileEntry
    Public Ofs As Integer
    Public Size As Integer
End Structure

Public Class NarcReader
    Public Entrys As Integer
    Public fe As FileEntry()
    Public fs As FileStream
    Private m_sFileName As String
    Public size As Long

    Public Sub New(strFileName As String)
        Me.m_sFileName = strFileName
        Me.fs = New FileStream(strFileName, FileMode.Open, FileAccess.ReadWrite)
        Dim reader As New BinaryReader(Me.fs)
        Dim buffer As Byte() = New Byte(15) {}
        reader.Read(buffer, 0, &H10)
        Me.size = BitConverter.ToUInt32(buffer, 8)
        Dim num As Integer = BitConverter.ToInt16(buffer, 12)
        Me.fs.Seek(CLng(num), SeekOrigin.Begin)
        buffer = New Byte(11) {}
        reader.Read(buffer, 0, 12)
        Dim num2 As Integer = BitConverter.ToInt32(buffer, 4)
        Me.Entrys = BitConverter.ToInt32(buffer, 8)
        Me.fe = New FileEntry(Me.Entrys - 1) {}
        For i As Integer = 0 To Me.Entrys - 1
            Me.fe(i).Ofs = reader.ReadInt32()
            Me.fe(i).Size = reader.ReadInt32() - Me.fe(i).Ofs
        Next
        Me.fs.Seek(CLng(num + num2), SeekOrigin.Begin)
        buffer = New Byte(15) {}
        reader.Read(buffer, 0, &H10)
        Dim num3 As Integer = BitConverter.ToInt32(buffer, 4)
        num3 = ((num + num3) + num2) + 8
        For j As Integer = 0 To Me.Entrys - 1
            Me.fe(j).Ofs += num3
        Next
        Me.fs.Close()
    End Sub

    Public Sub Close()
        Me.fs.Close()
    End Sub

    Public Function OpenEntry(id As Integer) As Integer
        Me.fs = New FileStream(Me.m_sFileName, FileMode.Open, FileAccess.ReadWrite)
        Me.fs.Seek(CLng(Me.fe(id).Ofs), SeekOrigin.Begin)
        Return 0
    End Function
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApriROMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalvaROMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.EsciToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AiutoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformazioniToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.dlgOpen = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lstItems = New System.Windows.Forms.ListBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.cmbAttack = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPassi = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPS = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.mnuMain.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.AiutoToolStripMenuItem})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(395, 24)
        Me.mnuMain.TabIndex = 0
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApriROMToolStripMenuItem, Me.SalvaROMToolStripMenuItem, Me.ToolStripMenuItem1, Me.EsciToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ApriROMToolStripMenuItem
        '
        Me.ApriROMToolStripMenuItem.Name = "ApriROMToolStripMenuItem"
        Me.ApriROMToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.ApriROMToolStripMenuItem.Text = "Open NARC..."
        '
        'SalvaROMToolStripMenuItem
        '
        Me.SalvaROMToolStripMenuItem.Name = "SalvaROMToolStripMenuItem"
        Me.SalvaROMToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.SalvaROMToolStripMenuItem.Text = "Save NARC..."
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(144, 6)
        '
        'EsciToolStripMenuItem
        '
        Me.EsciToolStripMenuItem.Name = "EsciToolStripMenuItem"
        Me.EsciToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.EsciToolStripMenuItem.Text = "Exit"
        '
        'AiutoToolStripMenuItem
        '
        Me.AiutoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InformazioniToolStripMenuItem})
        Me.AiutoToolStripMenuItem.Name = "AiutoToolStripMenuItem"
        Me.AiutoToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.AiutoToolStripMenuItem.Text = "Help"
        '
        'InformazioniToolStripMenuItem
        '
        Me.InformazioniToolStripMenuItem.Name = "InformazioniToolStripMenuItem"
        Me.InformazioniToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.InformazioniToolStripMenuItem.Text = "About"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lstItems)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox1.Location = New System.Drawing.Point(12, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(146, 186)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Item List"
        '
        'lstItems
        '
        Me.lstItems.Enabled = False
        Me.lstItems.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstItems.FormattingEnabled = True
        Me.lstItems.Location = New System.Drawing.Point(6, 19)
        Me.lstItems.Name = "lstItems"
        Me.lstItems.Size = New System.Drawing.Size(134, 160)
        Me.lstItems.TabIndex = 1
        '
        'Label20
        '
        Me.Label20.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label20.Location = New System.Drawing.Point(62, 217)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(242, 15)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Copyright © 2012 JackHack96  Matteo Iervasi"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(173, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Item price:"
        '
        'txtPrice
        '
        Me.txtPrice.Enabled = False
        Me.txtPrice.Location = New System.Drawing.Point(234, 33)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(67, 20)
        Me.txtPrice.TabIndex = 12
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PictureBox1)
        Me.GroupBox2.Controls.Add(Me.cmbAttack)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.txtPassi)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtPS)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Location = New System.Drawing.Point(176, 59)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(207, 154)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Special values"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(36, 99)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(144, 49)
        Me.PictureBox1.TabIndex = 17
        Me.PictureBox1.TabStop = False
        '
        'cmbAttack
        '
        Me.cmbAttack.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbAttack.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbAttack.Enabled = False
        Me.cmbAttack.FormattingEnabled = True
        Me.cmbAttack.Items.AddRange(New Object() {"Botta", "Colpokarate", "Doppiasberla", "Cometapugno", "Megapugno", "Giornopaga", "Fuocopugno", "Gelopugno", "Tuonopugno", "Graffio", "Presa", "Ghigliottina", "Ventagliente", "Danzaspada", "Taglio", "Raffica", "Attaccod'Ala", "Turbine", "Volo", "Legatutto", "Schianto", "Frustata", "Pestone", "Doppiocalcio", "Megacalcio", "Calciosalto", "Calciorullo", "Turbosabbia", "Bottintesta", "Incornata", "Furia", "Perforcorno", "Azione", "Corposcontro", "Avvolgibotta", "Riduttore", "Colpo", "Sdoppiatore", "Colpocoda", "Velenospina", "DoppioAgo", "Missilspillo", "Fulmisguardo", "Morso", "Ruggito", "Boato", "Canto", "Supersuono", "Sonicboom", "Inibitore", "Acido", "Braciere", "Lanciafiamme", "Nebbia", "Pistolacqua", "Idropompa", "Surf", "Geloraggio", "Bora", "Psicoraggio", "Bollaraggio", "Raggiaurora", "IperRaggio", "Beccata", "Perforbecco", "Sottomissione", "ColpoBasso", "Contatore", "MovimentoSismico", "Forza", "Assorbimento", "Megassorbimento", "Parassiseme", "Crescita", "Foglielama", "Solarraggio", "Velenpolvere", "Paralizzante", "Sonnifero", "Petalodanza", "Millebave", "IradiDrago", "Turbofuoco", "Tuonoshock", "Fulmine", "Tuononda", "Tuono", "Sassata", "Terremoto", "Abisso", "Fossa", "Tossina", "Confusione", "Psichico", "Ipnosi", "Meditazione", "Agilità", "AttaccoRapido", "Ira", "Teletrasporto", "OmbraNotturna", "Mimica", "Stridio", "Doppioteam", "Ripresa", "Rafforzatore", "Minimizzato", "MurodiFumo", "Stordiraggio", "Ritirata", "Ricciolscudo", "Barriera", "Schermoluce", "Nube", "Riflesso", "Focalenergia", "Pazienza", "Metronomo", "Speculmossa", "Autodistruzione", "Uovobomba", "Leccata", "Smog", "Fango", "Ossoclava", "Fuocobomba", "Cascata", "Tenaglia", "Comete", "Capocciata", "Sparalance", "Limitazione", "Amnesia", "Cinèsi", "Covauova", "Calcinvolo", "Bagliore", "Mangiasogni", "Velenogas", "AttaccoPioggia", "Sanguisuga", "Demonbacio", "Aeroattacco", "Trasformazione", "Bolla", "Stordipugno", "Spora", "Flash", "Psiconda", "Splash", "ScudoAcido", "Martellata", "Esplosione", "Sfuriate", "Ossomerang", "Riposo", "Frana", "Iperzanna", "Affilatore", "Conversione", "Tripletta", "Superzanna", "Lacerazione", "Sostituto", "Scontro", "Schizzo", "Triplocalcio", "Furto", "Ragnatela", "Leggimente", "Incubo", "Ruotafuoco", "Russare", "Maledizione", "Flagello", "Conversione2", "Aerocolpo", "Cottonspora", "Contropiede", "Dispetto", "Polneve", "Protezione", "Pugnorapido", "Visotruce", "Finta", "Dolcebacio", "Panciamburo", "Fangobomba", "Fangosberla", "Octazooka", "Punte", "Falcecannone", "Preveggenza", "Destinobbligato", "Ultimocanto", "Ventogelato", "Individua", "Ossoraffica", "Localizza", "Oltraggio", "Terrempesta", "Gigassorbimento", "Resistenza", "Fascino", "Rotolamento", "Falsofinale", "Bullo", "Buonlatte", "Scintilla", "Tagliofuria", "Alacciaio", "Malosguardo", "Attrazione", "Sonnolalia", "Rintoccasana", "Ritorno", "Regalino", "Frustrazione", "Salvaguardia", "Malcomune", "Magifuoco", "Magnitudo", "Dinamipugno", "Megacorno", "Dragospiro", "Staffetta", "Ripeti", "Inseguimento", "Rapigiro", "Profumino", "Codacciaio", "Ferrartigli", "Vitaltiro", "Mattindoro", "Sintesi", "Lucelunare", "Introforza", "Incrocolpo", "Tornado", "Pioggiadanza", "Giornodisole", "Sgranocchio", "Specchiovelo", "Psicamisù", "Extrarapido", "Forzantica", "PallaOmbra", "Divinazione", "Spaccaroccia", "Mulinello", "Picchiaduro", "Bruciapelo", "Baraonda", "Accumulo", "Sfoghenergia", "Introenergia", "Ondacalda", "Grandine", "Attaccalite", "Adulazione", "Fuocofatuo", "Memento", "Facciata", "Centripugno", "Maniereforti", "Sonoqui", "Naturforza", "Sottocarica", "Provocazione", "Altruismo", "Raggiro", "Giocodiruolo", "Desiderio", "Assistente", "Radicamento", "Troppoforte", "Magivelo", "Riciclo", "Vendetta", "Breccia", "Sbadiglio", "Privazione", "Rimonta", "Eruzione", "Baratto", "Esclusiva", "Rinfrescata", "Rancore", "Scippo", "Forzasegreta", "Sub", "Sberletese", "Camuffamento", "Codadiluce", "Abbagliante", "Foschisfera", "Danzadipiume", "Strampadanza", "Calciardente", "Fangata", "PallaGelo", "Pugnospine", "Pigro", "Granvoce", "Velenodenti", "Tritartigli", "Incendio", "Idrocannone", "Meteorpugno", "Sgomento", "PallaClima", "Aromaterapia", "Falselacrime", "Aerasoio", "Vampata", "Segugio", "Rocciotomba", "Ventargenteo", "Ferrostrido", "Meloderba", "Solletico", "Cosmoforza", "Zampillo", "Segnoraggio", "Pugnodombra", "Extrasenso", "Stramontante", "Sabbiotomba", "Purogelo", "Fanghiglia", "Semitraglia", "Aeroassalto", "Gelolancia", "Ferroscudo", "Blocco", "Gridodilotta", "Dragartigli", "Radicalbero", "Granfisico", "Rimbalzo", "Colpodifango", "Velenocoda", "Supplica", "Locomovolt", "Fogliamagica", "Docciascudo", "Calmamente", "Fendifoglia", "Dragodanza", "Cadutamassi", "Ondashock", "Idropulsar", "Obbliderio", "Psicoslancio", "Trespolo", "Gravità", "Miracolvista", "Svegliopacca", "Martelpugno", "Vortexpalla", "Curardore", "Acquadisale", "Dononaturale", "Fintoattacco", "Spennata", "Ventoincoda", "Acupressione", "Metalscoppio", "Retromarcia", "Zuffa", "Rivincita", "Garanzia", "Divieto", "Lancio", "Psicotrasfer", "Asso", "Anticura", "Strizzata", "Ingannoforza", "Gastroacido", "Fortuncanto", "Precedenza", "Copione", "Barattoforza", "Barattoscudo", "Punizione", "Ultimascelta", "Affannoseme", "Sbigoattacco", "Fielepunte", "Cuorbaratto", "Acquanello", "Magnetascesa", "Fuococarica", "Palmoforza", "Forzasfera", "Lucidatura", "Velenpuntura", "Neropulsar", "Nottesferza", "Idrondata", "Semebomba", "Eterelama", "ForbiceX", "Ronzio", "Dragopulsar", "Dragofuria", "Gemmoforza", "Assorbipugno", "Vuotonda", "Focalcolpo", "Energipalla", "Baldeali", "Geoforza", "Rapidscambio", "Gigaimpatto", "Congiura", "Pugnoscarica", "Slavina", "Geloscheggia", "Ombrartigli", "Fulmindenti", "Gelodenti", "Rogodenti", "Furtivombra", "Pantanobomba", "Psicotaglio", "CozzataZen", "Cristalcolpo", "Cannonflash", "Scalaroccia", "Scacciabruma", "Distortozona", "Dragobolide", "Scarica", "Lavasbuffo", "Verdebufera", "Vigorcolpo", "Devastomasso", "Velenocroce", "Sporcolancio", "Metaltestata", "Bombagnete", "Pietrataglio", "Incanto", "Levitoroccia", "Laccioerboso", "Schiamazzo", "Giudizio", "Coleomorso", "Raggioscossa", "Mazzuolegno", "Acquagetto", "Comandourto", "Comandoscudo", "Comandocura", "Zuccata", "Doppiosmash", "Fragortempo", "Fendispazio", "Lunardanza", "Sbriciolmano", "Magmaclisma", "Vuototetro", "Infuriaseme", "Funestovento", "Oscurotuffo"})
        Me.cmbAttack.Location = New System.Drawing.Point(58, 71)
        Me.cmbAttack.Name = "cmbAttack"
        Me.cmbAttack.Size = New System.Drawing.Size(143, 21)
        Me.cmbAttack.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 74)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Attack:"
        '
        'txtPassi
        '
        Me.txtPassi.Enabled = False
        Me.txtPassi.Location = New System.Drawing.Point(102, 44)
        Me.txtPassi.Name = "txtPassi"
        Me.txtPassi.Size = New System.Drawing.Size(54, 20)
        Me.txtPassi.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(87, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Number of steps:"
        '
        'txtPS
        '
        Me.txtPS.Enabled = False
        Me.txtPS.Location = New System.Drawing.Point(102, 19)
        Me.txtPS.Name = "txtPS"
        Me.txtPS.Size = New System.Drawing.Size(54, 20)
        Me.txtPS.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Recovered HPs:"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(395, 241)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.mnuMain)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuMain
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DPP ItemED"
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApriROMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalvaROMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EsciToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AiutoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InformazioniToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dlgOpen As System.Windows.Forms.OpenFileDialog
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lstItems As System.Windows.Forms.ListBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtPrice As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtPS As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtPassi As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbAttack As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox

End Class

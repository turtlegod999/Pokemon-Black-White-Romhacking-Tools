Nintendo Pok�mon Rom Editor.
Beta 4.0
by pichu2000/2001.


===Installation===

Extract your rar file on a directory, then follow these steps.

1) Open the program. 
2) It generate a Texture directory with a material.txt void file.
2) Delete this folder and extract files from Textures.zip

At the end of the process, you need to have a folder Textures with a bunch of btx file inner.
Be careful: You don't have a Textures/Textures/file.btx, but a Textyures/file.btx directly.


===Features===

1) Inner built-in NDS ROM explorer (Viewer, not Editor)
2) Support for these format.
   
   * Nintendo Archive (.NARC) - Open, Extract.
   * AB Archive (.AB) - Open, Extract.
   * Nintendo Model (.NSBMD) - Open, Save, Edit, Extract.
   
   In particular for Pok�mon Game we have.
   
   * Pok�mon Maps (Diamond, Pearl, Platinum, HeartGold, SoulSilver, Black, White, Black2, White2).
   ** Movement - Open, Save, Edit
   ** Object - Open, Save, Edit (Some bug with 5TH Generation Game).
   ** Model (Same features of NSBMD)
   * Pok�mon Script (Diamond, Pearl, Black, White) - WIP. Only View, with some problem regarding movement and a lot of unsupported command.
   * Pok�mon Events (Diamond, Pearl) - WIP Only view.

3) A very rough Hex Viewer for all file (into NDS ROM).


===FAQ===

1)How can I open a NDS ROM?

  - Go to File, Open and select your ROM. 
    Into the Tree Viewer, you can see a rapresentation of File System (Like Windows Directory) of your ROM.

2)How can I open a Map?
  
  - After your open the ROM, you need to go on a particular file (depending from ROM).

    * Diamond, Pearl : /root/fielddata/land_data/land_data_release.narc
    * Platinum : /root/fielddata/land_data/land_data.narc
    * Heart Gold, Soul Silver: /root/a/0/6/5/5
    * Black, White, Black2, White2 : /root/a/0/0/8/8

  - Now, you have two choice

    * Open a singe map file --> Doing this sequence: Right Click, Open, Click on little +, choose an internal file, Right Clik on it, Open as, Map.
    * Open entire NARC as container of Map --> Doing this sequence: Right Click, Open as, Narc (3D).
    
  - After, you must see a little Window with five choices: DP, Pl, HGSS, Bw, BW2, Other. You need to choice the right ROM origin, then click OK.
  
  - If all going well, a new Window appear, with a Blue Rectangle (we call it Renderer) on the right (If is Black, there's a bug).
    On the left of Renderer, we have four Slider (Zoom, Elevation, Rotate, Translation) that move Camera on Renderer.
    If you have chosen single map file, you need only to move these slider.
    If you have chosen NARC container, you need to choose the map from a List (on the left of Slider), then move Slider.

3)How can I edit a Map?

  - First you need to choice What edit.
  
  * Movements
  
    - Click on Tab Movements, and you see a big coloured Table (32*32 Cells).
    - Edit a Cell.
    - Click on Save Button 
     
    Note: You need to save the entire Map for have a real editing. 
     So, go to File, Save, Map and create a new File. Then File, Open, Map, choose Map Origin, and continue Editing).
    Note 2: For reinsert the Map into ROM, you need to use another Tool that can repack NARC.

  * Object

    - Click on Tab Object, and you see two elements: a big coloured Table similar to Movement (Not editable) and another table with Object Data.
    - Each Row rapresent an Object. You can Add, Remove Object. 
    - After, click on Save Button and follow the same steps of Movement to make a real editing (see Note and Note 2:)
  
  * Model
    
    This is the most complicated part.
    Each Model is divided into different polygon (You can choose which polygon view on Renderer through PolygonVisible command).
    You can edit:
    
    - Association Table: Table contained into SubTab Materials, that link each Polygon with a material, a texture and a palette.
      Over Association Table there are two lists that contains Texture Name and Palette Name that you can use for this map.
      Use these values to modify the Texture and Palette Columns of Association Table.  
      Remember to click Save button and to Save global (like Object and Materials).

    - Polygon Table: Table contained into SubTab Polygon.
      These table contains the OPENGL command for a single Polygon (Based on PolygonVisible value).
      For now you can change only Const and Const2 columns, not directly X,Y,Z.
      It's not easy to do, but for now it's the only way to edit a NSBMD.
      Remember to click Save button and to Save global.

4)There's a BUG, an Exception. Why?
  The motivation would be different for each exception, so tell me on my thread on pokecommunity, and I hope I can help you.

   
===== Credits =====

- Me
- SentryAlphaOmega, for his Basic Viewer
- All you that give me your feedback
- Nintendo and other friends. 


  
   
   
    
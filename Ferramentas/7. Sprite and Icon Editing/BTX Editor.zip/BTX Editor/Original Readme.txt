.BTX Editor

It can open pretty much all the btx files for trainer sprite.
Didnt really do much with the object/pokemon sprites, maybe later.

How to use:

Extract the btx files from the narc file. (/a/0/8/1 for HG/SS)

Open the Program.

Click the Open .btx button and select a btx file, if it a supported file (almost all the different trainer sprites) it will then be displayed.

You can save it as a PNG file, edit it, and open the edited image, or just open a premade sprite sheet in the proper format. (32 by 32x, where x is the number of frames)

Once a new image has been loaded into the program, you just click the Save .btx as... button to save the file.(At this time you can not overwrite the currently loaded file)

Replace the new .btx file with the one you want to edit and repack the narc file.

IMPORTANT:
MAX OF 16 COLORS.

﻿Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.IO
Imports System.Resources
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Public Class frmMain

    Private nr As NarcReader
    Private rect As Rectangle
    Private m_bitmap As Bitmap

    Private Sub ApriNARCToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ApriNARCToolStripMenuItem.Click
        dlgOpen.Title = "Apri file NARC..."
        dlgOpen.Filter = "File NARC (*.narc)|*.narc"
        Me.ComboBox1.Items.Clear()
        If (dlgOpen.ShowDialog() = DialogResult.OK) Then
            Me.nr = New NarcReader(dlgOpen.FileName)
            For i As Integer = 0 To Me.nr.Entrys - 1
                Me.ComboBox1.Items.Add(String.Format("Item{0} ({1:X})", i, Me.nr.fe(i).Size))
            Next
        End If
    End Sub

    Private Sub SalvaNARCToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalvaNARCToolStripMenuItem.Click
        Dim index As Integer = Me.ComboBox1.Items.IndexOf(Me.ComboBox1.Text)
        If Me.nr.fe(index).Size = &H1930 Then
            Me.nr.OpenEntry(index)
            Me.SaveBin(Me.nr.fs)
            Me.nr.Close()
        End If
        If Me.nr.fe(index).Size = &H48 Then
            Me.nr.OpenEntry(index)
            Me.SavePal(Me.nr.fs)
            Me.nr.Close()
        End If
    End Sub

    Private Sub SaveBin(fs As FileStream)
        Dim writer As New BinaryWriter(fs)
        Me.rect = New Rectangle(0, 0, 160, 80)
        Dim bitmapdata As BitmapData = Me.m_bitmap.LockBits(Me.rect, ImageLockMode.[ReadOnly], Me.m_bitmap.PixelFormat)
        Dim source As IntPtr = bitmapdata.Scan0
        Dim destination As Byte() = New Byte(12799) {}
        Marshal.Copy(source, destination, 0, &H3200)
        Me.m_bitmap.UnlockBits(bitmapdata)
        Dim numArray As UShort() = New UShort(3199) {}
        For i As Integer = 0 To 3199
            numArray(i) = CUShort((((destination(i * 4) And 15) Or ((destination((i * 4) + 1) And 15) << 4)) Or ((destination((i * 4) + 2) And 15) << 8)) Or ((destination((i * 4) + 3) And 15) << 12))
        Next
        Dim num2 As UInteger = &H7A53
        For j As Integer = &HC7F To 0 Step -1
            num2 += numArray(j)
        Next
        For k As Integer = &HC7F To 0 Step -1
            Dim numArray2 As UShort()
            Dim ptr2 As IntPtr
            numArray2 = numArray
            ptr2 = New IntPtr(k)
            numArray2(CInt(ptr2)) = CUShort(numArray2(CInt(ptr2)) Xor CUShort(num2 And &HFFFF))
            num2 *= &H41C64E6D
            num2 += &H6073
        Next
        Dim buffer2 As Byte() = New Byte() {&H52, &H47, &H43, &H4E, &HFF, &HFE, _
         0, 1, &H30, &H19, 0, 0, _
         &H10, 0, 1, 0, &H52, &H41, _
         &H48, &H43, &H20, &H19, 0, 0, _
         10, 0, 20, 0, 3, 0, _
         0, 0, 0, 0, 0, 0, _
         1, 0, 0, 0, 0, &H19, _
         0, 0, &H18, 0, 0, 0}
        For m As Integer = 0 To 47
            writer.Write(buffer2(m))
        Next
        For n As Integer = 0 To 3199
            writer.Write(numArray(n))
        Next
    End Sub
    Private Sub SaveBinary_Click(sender As Object, e As EventArgs)
        dlgSave.Title = "Salva immagine come..."
        dlgSave.OverwritePrompt = True
        dlgSave.CheckPathExists = True
        dlgSave.Filter = "File BIN (*.bin)|*.bin"
        If dlgSave.ShowDialog() = DialogResult.OK Then
            Dim fs As New FileStream(dlgSave.FileName, FileMode.Create, FileAccess.Write)
            Me.SaveBin(fs)
        End If
    End Sub
    Private Sub SavePal(fs As FileStream)
        Dim buffer As Byte() = New Byte() {&H52, &H4C, &H43, &H4E, &HFF, &HFE, _
         0, 1, &H48, 0, 0, 0, _
         &H10, 0, 1, 0, &H54, &H54, _
         &H4C, 80, &H38, 0, 0, 0, _
         4, 0, 10, 0, 0, 0, _
         0, 0, &H20, 0, 0, 0, _
         &H10, 0, 0, 0}
        Dim writer As New BinaryWriter(fs)
        writer.Write(buffer, 0, 40)
        Dim palette As ColorPalette = Me.m_bitmap.Palette
        Dim numArray As UShort() = New UShort(15) {}
        For i As Integer = 0 To 15
            numArray(i) = CUShort((((palette.Entries(i).R >> 3) And &H1F) Or (((palette.Entries(i).G >> 3) And &H1F) << 5)) Or (((palette.Entries(i).B >> 3) And &H1F) << 10))
        Next
        For j As Integer = 0 To 15
            writer.Write(numArray(j))
        Next
    End Sub
    Private Sub SetPal(fs As FileStream)
        If Me.m_bitmap Is Nothing Then
            MessageBox.Show("Seleziona un immagine")
        Else
            fs.Seek(40L, SeekOrigin.Current)
            Dim numArray As UShort() = New UShort(15) {}
            Dim reader As New BinaryReader(fs)
            For i As Integer = 0 To 15
                numArray(i) = reader.ReadUInt16()
            Next
            Dim bitmap As New Bitmap(1, 1, PixelFormat.Format4bppIndexed)
            Dim palette As ColorPalette = bitmap.Palette
            For j As Integer = 0 To 15
                palette.Entries(j) = Color.FromArgb((numArray(j) And &H1F) << 3, ((numArray(j) >> 5) And &H1F) << 3, ((numArray(j) >> 10) And &H1F) << 3)
            Next
            Me.m_bitmap.Palette = palette
            Me.m_pictureBox.Image = Me.m_bitmap
        End If
    End Sub
    Private Sub MakeImage(fs As FileStream)
        fs.Seek(&H30L, SeekOrigin.Current)
        Dim reader As New BinaryReader(fs)
        Dim numArray As UShort() = New UShort(3199) {}
        For i As Integer = 0 To 3199
            numArray(i) = reader.ReadUInt16()
        Next
        Dim num As Object
        num = numArray(3199)
        Dim j As Object = 3199
        For j = 3199 To 0 Step -1
            Dim numArray2() As UShort
            Dim ptr2 As IntPtr
            numArray2 = numArray
            ptr2 = New IntPtr(CInt(j))
            numArray2(CInt(ptr2)) = CUShort(numArray2(CInt(ptr2)) Xor CUShort(num And &HFFFF))
            num = num * 1103515245
            num = num + 24691
        Next
        Me.m_bitmap = New Bitmap(160, 80, PixelFormat.Format8bppIndexed)
        Me.rect = New Rectangle(0, 0, 160, 80)
        Dim source As Byte() = New Byte(12799) {}
        For k As Integer = 0 To 3199
            source(k * 4) = CByte(numArray(k) And 15)
            source((k * 4) + 1) = CByte((numArray(k) >> 4) And 15)
            source((k * 4) + 2) = CByte((numArray(k) >> 8) And 15)
            source((k * 4) + 3) = CByte((numArray(k) >> 12) And 15)
        Next
        Dim bitmapdata As BitmapData = Me.m_bitmap.LockBits(Me.rect, ImageLockMode.[WriteOnly], Me.m_bitmap.PixelFormat)
        Dim destination As IntPtr = bitmapdata.Scan0
        Marshal.Copy(source, 0, destination, &H3200)
        Me.m_bitmap.UnlockBits(bitmapdata)
        Dim bitmap As New Bitmap(1, 1, PixelFormat.Format4bppIndexed)
        Dim palette As ColorPalette = bitmap.Palette
        For m As Integer = 0 To 15
            palette.Entries(m) = Color.FromArgb(m << 4, m << 4, m << 4)
        Next
        Me.m_bitmap.Palette = palette
        Me.m_pictureBox.Image = Me.m_bitmap
    End Sub

    Private Sub ApriPNGToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ApriPNGToolStripMenuItem.Click
        dlgOpen.Title = "Apri immagine..."
        dlgOpen.CheckPathExists = True
        dlgOpen.Filter = "Immagine PNG (*.png)|*.png"
        dlgOpen.ShowHelp = True
        If dlgOpen.ShowDialog() = DialogResult.OK Then
            Dim fileName As String = dlgOpen.FileName
            Me.m_bitmap = New Bitmap(fileName)
            If Me.m_bitmap.PixelFormat <> PixelFormat.Format8bppIndexed Then
                MessageBox.Show("L'immagine non è indexata a 8bpp! Probabilmente non funzionerà.")
            End If
            If (Me.m_bitmap.Height <> 80) OrElse (Me.m_bitmap.Width <> 160) Then
                MessageBox.Show("L'immagine deve essere di 80x160. L'immagine verrà adattata.")
                Me.m_bitmap = New Bitmap(Me.m_bitmap, 160, 80)
            End If
            Me.m_pictureBox.Image = Me.m_bitmap
        End If
    End Sub

    Private Sub SalvaPNGToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalvaPNGToolStripMenuItem.Click
        dlgSave.Title = "Salva immagine..."
        dlgSave.OverwritePrompt = True
        dlgSave.CheckPathExists = True
        dlgSave.Filter = "Immagine PNG (*.png)|*.png"
        dlgSave.ShowHelp = True
        If dlgSave.ShowDialog() = DialogResult.OK Then
            Dim fileName As String = dlgSave.FileName
            Me.m_bitmap.Save(fileName, ImageFormat.Png)
        End If
    End Sub

    Private Sub EsciToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles EsciToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ApriDirectToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ApriDirectToolStripMenuItem.Click
        dlgOpen.Filter = "Tutti i file (*.*)|*.*"
        Dim filter As String = dlgOpen.Filter
        dlgOpen.Title = "File Bin"
        dlgOpen.ShowHelp = True
        If dlgOpen.ShowDialog() = DialogResult.OK Then
            Dim fs As New FileStream(dlgOpen.FileName, FileMode.Open, FileAccess.Read)
            Me.MakeImage(fs)
        End If
    End Sub

    Private Sub ApriPalDirectToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ApriPalDirectToolStripMenuItem.Click
        dlgOpen.Filter = "Tutti i file (*.*)|*.*"
        Dim filter As String = dlgOpen.Filter
        dlgOpen.InitialDirectory = Environment.CurrentDirectory
        dlgOpen.Title = "File Pal"
        If dlgOpen.ShowDialog() = DialogResult.OK Then
            Dim fs As New FileStream(dlgOpen.FileName, FileMode.Open, FileAccess.Read)
            Me.SetPal(fs)
        End If
    End Sub

    Private Sub SalvaDirectToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalvaDirectToolStripMenuItem.Click
        dlgSave.Title = "Salva immagine..."
        dlgSave.OverwritePrompt = True
        dlgSave.CheckPathExists = True
        dlgSave.Filter = "File BIN (*.bin)|*.bin"
        If dlgSave.ShowDialog() = DialogResult.OK Then
            Dim fs As New FileStream(dlgSave.FileName, FileMode.Create, FileAccess.Write)
            Me.SaveBin(fs)
        End If
    End Sub

    Private Sub SalvaPalDirectToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalvaPalDirectToolStripMenuItem.Click
        dlgSave.Filter = "File BIN (*.bin)|*.bin"
        dlgSave.OverwritePrompt = True
        Dim filter As String = dlgSave.Filter
        dlgSave.Title = "Salva file PAL"
        If dlgSave.ShowDialog() = DialogResult.OK Then
            Dim fs As New FileStream(dlgSave.FileName, FileMode.Create, FileAccess.Write)
            Me.SavePal(fs)
            fs.Close()
        End If
    End Sub

    Private Sub InformazioniToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InformazioniToolStripMenuItem.Click
        MsgBox("PokePic DS - Reloaded Version by JackHack96")
    End Sub

    Private Sub cmdApriPNG_Click(sender As System.Object, e As System.EventArgs) Handles cmdApriPNG.Click
        dlgOpen.Title = "Open Image As"
        dlgOpen.CheckPathExists = True
        dlgOpen.Filter = "*.png|*.png"
        dlgOpen.ShowHelp = True
        If dlgOpen.ShowDialog() = DialogResult.OK Then
            Dim fileName As String = dlgOpen.FileName
            Me.m_bitmap = New Bitmap(fileName)
            If Me.m_bitmap.PixelFormat <> PixelFormat.Format8bppIndexed Then
                MessageBox.Show("Png has to be 8bpp Indexed! This image will probably not work.")
            End If
            If (Me.m_bitmap.Height <> 80) OrElse (Me.m_bitmap.Width <> 160) Then
                MessageBox.Show("Binmap hast to be 80x160. Bitmap will be Scaled")
                Me.m_bitmap = New Bitmap(Me.m_bitmap, 160, 80)
            End If
            Me.m_pictureBox.Image = Me.m_bitmap
        End If
    End Sub

    Private Sub cmdSalvaPNG_Click(sender As System.Object, e As System.EventArgs) Handles cmdSalvaPNG.Click
        dlgSave.Title = "Save Image As"
        dlgSave.OverwritePrompt = True
        dlgSave.CheckPathExists = True
        dlgSave.Filter = "*.png|*.png"
        dlgSave.ShowHelp = True
        If dlgSave.ShowDialog() = DialogResult.OK Then
            Dim fileName As String = dlgSave.FileName
            Me.m_bitmap.Save(fileName, ImageFormat.Png)
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim index As Integer = Me.ComboBox1.Items.IndexOf(Me.ComboBox1.Text)
        If Me.nr.fe(index).Size = &H1930 Then
            Me.nr.OpenEntry(index)
            Me.MakeImage(Me.nr.fs)
            Me.nr.Close()
            If SelezionaAutomaticamentePALToolStripMenuItem.Checked Then
                For i As Integer = 0 To 19
                    If Me.nr.fe(index + i).Size = &H48 Then
                        Me.nr.OpenEntry(index + i)
                        Me.SetPal(Me.nr.fs)
                        Me.nr.Close()
                        Exit For
                    End If
                Next
            End If
        End If
        If Me.nr.fe(index).Size = &H48 Then
            Me.nr.OpenEntry(index)
            Me.SetPal(Me.nr.fs)
            Me.nr.Close()
        End If
    End Sub
End Class

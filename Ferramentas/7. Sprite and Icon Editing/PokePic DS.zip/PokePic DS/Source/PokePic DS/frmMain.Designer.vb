﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApriNARCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalvaNARCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ApriPNGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalvaPNGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.EsciToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpzioniToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelezionaAutomaticamentePALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EspertoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApriDirectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApriPalDirectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
        Me.SalvaDirectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalvaPalDirectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AiutoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformazioniToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.m_pictureBox = New System.Windows.Forms.PictureBox()
        Me.dlgOpen = New System.Windows.Forms.OpenFileDialog()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.cmdApriPNG = New System.Windows.Forms.Button()
        Me.cmdSalvaPNG = New System.Windows.Forms.Button()
        Me.dlgSave = New System.Windows.Forms.SaveFileDialog()
        Me.mnuMain.SuspendLayout()
        CType(Me.m_pictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.OpzioniToolStripMenuItem, Me.EspertoToolStripMenuItem, Me.AiutoToolStripMenuItem})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(361, 24)
        Me.mnuMain.TabIndex = 0
        Me.mnuMain.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApriNARCToolStripMenuItem, Me.SalvaNARCToolStripMenuItem, Me.ToolStripMenuItem1, Me.ApriPNGToolStripMenuItem, Me.SalvaPNGToolStripMenuItem, Me.ToolStripMenuItem2, Me.EsciToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ApriNARCToolStripMenuItem
        '
        Me.ApriNARCToolStripMenuItem.Name = "ApriNARCToolStripMenuItem"
        Me.ApriNARCToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.ApriNARCToolStripMenuItem.Text = "Apri .NARC..."
        '
        'SalvaNARCToolStripMenuItem
        '
        Me.SalvaNARCToolStripMenuItem.Name = "SalvaNARCToolStripMenuItem"
        Me.SalvaNARCToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.SalvaNARCToolStripMenuItem.Text = "Salva .NARC..."
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(145, 6)
        '
        'ApriPNGToolStripMenuItem
        '
        Me.ApriPNGToolStripMenuItem.Name = "ApriPNGToolStripMenuItem"
        Me.ApriPNGToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.ApriPNGToolStripMenuItem.Text = "Apri PNG..."
        '
        'SalvaPNGToolStripMenuItem
        '
        Me.SalvaPNGToolStripMenuItem.Name = "SalvaPNGToolStripMenuItem"
        Me.SalvaPNGToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.SalvaPNGToolStripMenuItem.Text = "Salva PNG..."
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(145, 6)
        '
        'EsciToolStripMenuItem
        '
        Me.EsciToolStripMenuItem.Name = "EsciToolStripMenuItem"
        Me.EsciToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.EsciToolStripMenuItem.Text = "Esci"
        '
        'OpzioniToolStripMenuItem
        '
        Me.OpzioniToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SelezionaAutomaticamentePALToolStripMenuItem})
        Me.OpzioniToolStripMenuItem.Name = "OpzioniToolStripMenuItem"
        Me.OpzioniToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.OpzioniToolStripMenuItem.Text = "Opzioni"
        '
        'SelezionaAutomaticamentePALToolStripMenuItem
        '
        Me.SelezionaAutomaticamentePALToolStripMenuItem.Checked = True
        Me.SelezionaAutomaticamentePALToolStripMenuItem.CheckOnClick = True
        Me.SelezionaAutomaticamentePALToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.SelezionaAutomaticamentePALToolStripMenuItem.Name = "SelezionaAutomaticamentePALToolStripMenuItem"
        Me.SelezionaAutomaticamentePALToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.SelezionaAutomaticamentePALToolStripMenuItem.Text = "Seleziona automaticamente PAL"
        '
        'EspertoToolStripMenuItem
        '
        Me.EspertoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApriDirectToolStripMenuItem, Me.ApriPalDirectToolStripMenuItem, Me.ToolStripMenuItem3, Me.SalvaDirectToolStripMenuItem, Me.SalvaPalDirectToolStripMenuItem})
        Me.EspertoToolStripMenuItem.Name = "EspertoToolStripMenuItem"
        Me.EspertoToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.EspertoToolStripMenuItem.Text = "Esperto"
        '
        'ApriDirectToolStripMenuItem
        '
        Me.ApriDirectToolStripMenuItem.Name = "ApriDirectToolStripMenuItem"
        Me.ApriDirectToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.ApriDirectToolStripMenuItem.Text = "Apri Direct"
        '
        'ApriPalDirectToolStripMenuItem
        '
        Me.ApriPalDirectToolStripMenuItem.Name = "ApriPalDirectToolStripMenuItem"
        Me.ApriPalDirectToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.ApriPalDirectToolStripMenuItem.Text = "Apri Pal Direct"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(151, 6)
        '
        'SalvaDirectToolStripMenuItem
        '
        Me.SalvaDirectToolStripMenuItem.Name = "SalvaDirectToolStripMenuItem"
        Me.SalvaDirectToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.SalvaDirectToolStripMenuItem.Text = "Salva Direct"
        '
        'SalvaPalDirectToolStripMenuItem
        '
        Me.SalvaPalDirectToolStripMenuItem.Name = "SalvaPalDirectToolStripMenuItem"
        Me.SalvaPalDirectToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.SalvaPalDirectToolStripMenuItem.Text = "Salva Pal Direct"
        '
        'AiutoToolStripMenuItem
        '
        Me.AiutoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InformazioniToolStripMenuItem})
        Me.AiutoToolStripMenuItem.Name = "AiutoToolStripMenuItem"
        Me.AiutoToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.AiutoToolStripMenuItem.Text = "Aiuto"
        '
        'InformazioniToolStripMenuItem
        '
        Me.InformazioniToolStripMenuItem.Name = "InformazioniToolStripMenuItem"
        Me.InformazioniToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.InformazioniToolStripMenuItem.Text = "Informazioni"
        '
        'm_pictureBox
        '
        Me.m_pictureBox.BackColor = System.Drawing.SystemColors.ControlDark
        Me.m_pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.m_pictureBox.Location = New System.Drawing.Point(12, 27)
        Me.m_pictureBox.Name = "m_pictureBox"
        Me.m_pictureBox.Size = New System.Drawing.Size(337, 184)
        Me.m_pictureBox.TabIndex = 1
        Me.m_pictureBox.TabStop = False
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(12, 217)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox1.TabIndex = 2
        '
        'cmdApriPNG
        '
        Me.cmdApriPNG.Location = New System.Drawing.Point(181, 217)
        Me.cmdApriPNG.Name = "cmdApriPNG"
        Me.cmdApriPNG.Size = New System.Drawing.Size(83, 21)
        Me.cmdApriPNG.TabIndex = 3
        Me.cmdApriPNG.Text = "Apri PNG"
        Me.cmdApriPNG.UseVisualStyleBackColor = True
        '
        'cmdSalvaPNG
        '
        Me.cmdSalvaPNG.Location = New System.Drawing.Point(266, 217)
        Me.cmdSalvaPNG.Name = "cmdSalvaPNG"
        Me.cmdSalvaPNG.Size = New System.Drawing.Size(83, 21)
        Me.cmdSalvaPNG.TabIndex = 4
        Me.cmdSalvaPNG.Text = "Salva PNG"
        Me.cmdSalvaPNG.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(361, 249)
        Me.Controls.Add(Me.cmdSalvaPNG)
        Me.Controls.Add(Me.cmdApriPNG)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.m_pictureBox)
        Me.Controls.Add(Me.mnuMain)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.mnuMain
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PokePic DS - Reloaded Version"
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        CType(Me.m_pictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApriNARCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalvaNARCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ApriPNGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalvaPNGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EsciToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpzioniToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SelezionaAutomaticamentePALToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EspertoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApriDirectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApriPalDirectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SalvaDirectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalvaPalDirectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AiutoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InformazioniToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_pictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents dlgOpen As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents cmdApriPNG As System.Windows.Forms.Button
    Friend WithEvents cmdSalvaPNG As System.Windows.Forms.Button
    Friend WithEvents dlgSave As System.Windows.Forms.SaveFileDialog

End Class

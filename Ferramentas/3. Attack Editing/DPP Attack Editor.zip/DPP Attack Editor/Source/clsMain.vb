﻿Public Class Parametro

    Private m_chiave As String
    Private m_valore As String

    Public Property Chiave() As String
        Get
            Return m_chiave
        End Get
        Set(ByVal value As String)
            m_chiave = value
        End Set
    End Property

    Public Property Valore() As String
        Get
            Return m_valore
        End Get
        Set(ByVal value As String)
            m_valore = value
        End Set
    End Property

    Public Sub New(ByVal nomeChiave As String, ByVal valoreChiave As String)

        m_chiave = nomeChiave
        m_valore = valoreChiave

    End Sub

    Public Overrides Function ToString() As String

        Return m_chiave & " = " & m_valore

    End Function

End Class
Public Class Sezione
    Inherits List(Of Parametro)

    Private m_nome As String
    Private m_commento As String

    Public Property Nome() As String
        Get
            Return m_nome
        End Get
        Set(ByVal value As String)
            m_nome = value
        End Set
    End Property

    Public Property Commento() As String
        Get
            Return m_commento
        End Get
        Set(ByVal value As String)
            m_commento = value
        End Set
    End Property

    Public Sub New(ByVal nome As String, Optional ByVal commento As String = "")

        m_nome = nome
        If commento <> "" Then m_commento = commento

    End Sub

    Public Function GetParametroByNome(ByVal nomeParametro As String) As Parametro

        For Each P As Parametro In Me
            If P.Chiave = nomeParametro Then Return P
        Next
        Return Nothing

    End Function

End Class
Public Class FileIni
    Inherits List(Of Sezione)

    Private m_nomeFileCompleto As String

    Public Sub New(ByVal nomeFileCompleto As String)

        m_nomeFileCompleto = nomeFileCompleto

    End Sub

    Public Sub Carica()

        Me.Clear()
        Dim linee As String() = IO.File.ReadAllLines(m_nomeFileCompleto)
        For Each l As String In linee
            If l <> "" Then
                Select Case l.First
                    Case ";" 'Commento di Sezione
                        Me.Last.Commento = l.Replace("; ", "")

                    Case "[" 'Sezione
                        Me.Add(New Sezione(l.Replace("[", "").Replace("]", "")))

                    Case Else 'Parametro ?
                        If l.Contains("=") Then Me.Last.Add(New Parametro(l.Split("=")(0).Trim, l.Split("=")(1).Trim))
                End Select
            End If
        Next

    End Sub

    Public Sub Salva()

        If Me.Count = 0 Then Exit Sub
        Dim linee As New List(Of String)

        For Each S As Sezione In Me
            linee.Add("[" & S.Nome & "]")
            If S.Commento <> "" Then linee.Add("; " & S.Commento)
            For Each P As Parametro In S
                linee.Add(P.ToString)
            Next
            linee.Add("")
        Next

        IO.File.WriteAllLines(m_nomeFileCompleto, linee)

    End Sub

    Public Function GetSezioneByNome(ByVal nomeSezione As String) As Sezione

        For Each S As Sezione In Me
            If S.Nome = nomeSezione Then Return S
        Next
        Return Nothing

    End Function

End Class
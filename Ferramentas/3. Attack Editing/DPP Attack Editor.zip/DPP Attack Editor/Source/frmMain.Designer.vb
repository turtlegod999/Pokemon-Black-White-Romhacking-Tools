﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApriROMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalvaROMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.EsciToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AiutoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformazioniToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LinguaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItalianoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IngleseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmbAttack = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtChance = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtAcc = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPP = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPower = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbEffect = New System.Windows.Forms.ComboBox()
        Me.cmbType = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbTarget = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dlgOpen = New System.Windows.Forms.OpenFileDialog()
        Me.mnuMain.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.AiutoToolStripMenuItem})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(344, 24)
        Me.mnuMain.TabIndex = 0
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApriROMToolStripMenuItem, Me.SalvaROMToolStripMenuItem, Me.ToolStripMenuItem1, Me.EsciToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ApriROMToolStripMenuItem
        '
        Me.ApriROMToolStripMenuItem.Name = "ApriROMToolStripMenuItem"
        Me.ApriROMToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ApriROMToolStripMenuItem.Text = "Apri NARC..."
        '
        'SalvaROMToolStripMenuItem
        '
        Me.SalvaROMToolStripMenuItem.Name = "SalvaROMToolStripMenuItem"
        Me.SalvaROMToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.SalvaROMToolStripMenuItem.Text = "Salva NARC..."
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(142, 6)
        '
        'EsciToolStripMenuItem
        '
        Me.EsciToolStripMenuItem.Name = "EsciToolStripMenuItem"
        Me.EsciToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.EsciToolStripMenuItem.Text = "Esci"
        '
        'AiutoToolStripMenuItem
        '
        Me.AiutoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InformazioniToolStripMenuItem, Me.LinguaToolStripMenuItem})
        Me.AiutoToolStripMenuItem.Name = "AiutoToolStripMenuItem"
        Me.AiutoToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.AiutoToolStripMenuItem.Text = "Aiuto"
        '
        'InformazioniToolStripMenuItem
        '
        Me.InformazioniToolStripMenuItem.Name = "InformazioniToolStripMenuItem"
        Me.InformazioniToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.InformazioniToolStripMenuItem.Text = "Informazioni"
        '
        'LinguaToolStripMenuItem
        '
        Me.LinguaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ItalianoToolStripMenuItem, Me.IngleseToolStripMenuItem})
        Me.LinguaToolStripMenuItem.Name = "LinguaToolStripMenuItem"
        Me.LinguaToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.LinguaToolStripMenuItem.Text = "Lingua"
        '
        'ItalianoToolStripMenuItem
        '
        Me.ItalianoToolStripMenuItem.Image = CType(resources.GetObject("ItalianoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ItalianoToolStripMenuItem.Name = "ItalianoToolStripMenuItem"
        Me.ItalianoToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.ItalianoToolStripMenuItem.Text = "Italiano"
        '
        'IngleseToolStripMenuItem
        '
        Me.IngleseToolStripMenuItem.Image = CType(resources.GetObject("IngleseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.IngleseToolStripMenuItem.Name = "IngleseToolStripMenuItem"
        Me.IngleseToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.IngleseToolStripMenuItem.Text = "Inglese"
        '
        'cmbAttack
        '
        Me.cmbAttack.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbAttack.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbAttack.Enabled = False
        Me.cmbAttack.FormattingEnabled = True
        Me.cmbAttack.Location = New System.Drawing.Point(12, 27)
        Me.cmbAttack.Name = "cmbAttack"
        Me.cmbAttack.Size = New System.Drawing.Size(321, 21)
        Me.cmbAttack.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 135)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Effetto:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtChance)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtAcc)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtPP)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtPower)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 54)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(321, 67)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dati attacco"
        '
        'txtChance
        '
        Me.txtChance.Enabled = False
        Me.txtChance.Location = New System.Drawing.Point(240, 39)
        Me.txtChance.Name = "txtChance"
        Me.txtChance.Size = New System.Drawing.Size(67, 20)
        Me.txtChance.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(143, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Chance di effetto:"
        '
        'txtAcc
        '
        Me.txtAcc.Enabled = False
        Me.txtAcc.Location = New System.Drawing.Point(240, 13)
        Me.txtAcc.Name = "txtAcc"
        Me.txtAcc.Size = New System.Drawing.Size(67, 20)
        Me.txtAcc.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(143, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Precisione:"
        '
        'txtPP
        '
        Me.txtPP.Enabled = False
        Me.txtPP.Location = New System.Drawing.Point(61, 39)
        Me.txtPP.Name = "txtPP"
        Me.txtPP.Size = New System.Drawing.Size(67, 20)
        Me.txtPP.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 42)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "PP:"
        '
        'txtPower
        '
        Me.txtPower.Enabled = False
        Me.txtPower.Location = New System.Drawing.Point(61, 13)
        Me.txtPower.Name = "txtPower"
        Me.txtPower.Size = New System.Drawing.Size(67, 20)
        Me.txtPower.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Potenza:"
        '
        'cmbEffect
        '
        Me.cmbEffect.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbEffect.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbEffect.Enabled = False
        Me.cmbEffect.FormattingEnabled = True
        Me.cmbEffect.Items.AddRange(New Object() {"0 - Attacco normale", "1 - Addormenta l'avversario", "2 - Colpo + Veleno", "3 - Colpo + Guarigione", "4 - Colpo + Scottatura", "5 - Colpo + Congelamento", "6 - Colpo + Paralisi", "7 - Colpo + Autodistruzione", "8 - Colpo se l'avversario stà dormendo", "9 - Copia l'attacco dell'avversario", "10 - Aumenta il proprio attacco di 1", "11 - Aumenta la propria difesa di 1", "12 -", "13 - Aumenta il proprio attacco sp di 1", "14 - ", "15 -", "16 - Aumenta di 1 l'elusione", "17 - Colpo sicuro al 100%", "18 - Abbassa di 1 l'attacco nemico", "19 - Abbassa di 1 la difesa nemica", "20 - Abbassa di 1 l'elusione nemica*", "21 -", "22 -", "23 - Abbassa di 1 la precisione nemica", "24 - Abbassa l'elusione nemica", "25 - Nebbia? Rimette a posto le statistiche?*", "26 -", "27 - Attacca 2 o 3 volte, ma confonde", "28 - Manda via l'avversario dalla lotta", "29 - Colpisce 2-5 volte", "30 - Tipo del pokémon del giocatore = Tipo dell'ultimo attacco nemico", "31 - ", "32 - Recuperà il 50% dei PS", "33 - Cura il veleno", "34 - Effetto Giornodipaga (da soldi)", "35 - Effetto Light Screen?*", "36 - Può paralizzare, bruciare, congelare", "37 - Effetto Riposo", "38 - K.O. in un colpo", "39 - Il prossimo attacco avrà un alta probabilità di brutto colpo", "40 - Colpo che toglie metà PS nemici", "41 - Colpo che toglie 40 PS al nemico", "42 - Attacco stile Legatutto", "43 - Aumenta la probabilità di brutti colpi ", "44 - Doppio calcio? Doppio colpo?*", "45 - Calcio salto/Calcinvolo", "46 - Previene la riduzione statistiche per 2-5 turni", "47 - Effetto Focalenergia?*", "48 - Colpo con contraccolpo", "49 - Confonde", "50 - Aumenta il proprio attacco di 2", "51 - Aumenta la propria difesa di 2", "52 - Aumenta la propria velocità di 2", "53 - Aumenta l'attacco speciale di 2", "54 - Aumenta la difesa speciale di 2", "55 - ", "56 -", "57 - Effetto Trasformazione", "58 - Diminuisce l'attacco nemico di 2", "59 - Diminuisce la difesa nemica di 2", "60 - Diminuisce la velocità nemica di 2", "61 - ", "62 - Diminuisce la difesa sp nemica di 2", "63 -", "64 -", "65 - Effetto Riflesso? Raddoppia difesa per 2-5 turni?*", "66 - Avvelena certi nemici", "67 - Paralizza certi nemici", "68 - Diminuisce l'attacco nemico", "69 - Diminuisce la difesa nemica", "70 - Diminuisce la velocità nemica", "71 - Diminuisce l'attacco sp nemico", "72 - Diminuisce la difesa sp nemica", "73 - Diminuisce la precisione nemica", "74 - ", "75 - Effetto Aerassalto", "76 - Può confondere", "77 - Effetto doppio ago?*", "78 - Effetto Vitaltiro", "79 - Crea un sostituto", "80 - Necessita di ricarica", "81 - Effetto Ira?*", "82 - Copia attacco (Mimica)", "83 - Attacco casuale (Metronomo)", "84 - Effetto Parassiseme?*", "85 - Effetto Splash", "86 - Disabilita mossa (Inibitore)", "87 - Danno = Livello del pokémon", "88 - Danno casuale", "89 - Doppio danno", "90 - Effetto bis*", "91 - Effetto malcomune", "92 - Attacca solamente quando il nemico dorme. Potrebbe svegliare.*", "93 - Effetto Conversione2", "94 - Il prossimo colpo colpirà di sicuro", "95 -", "96 -", "97 - Effetto Sonnolalia", "98 - Effetto Destino obbligato", "99 - Effetto Flagello", "100 - Effetto Triplocalcio/Dispetto", "101 - Lascia ad 1 PS", "102 - Cura i problemi di stato", "103 - Attacca per primo", "104 - ", "105 - Potrebbe rubare eventuali strumenti tenuti dal nemico", "106 - Il nemico non può scappare", "107 - Effetto Incubo?*", "108 - Effetto Minimizzazione", "109 - Effetto Maledizione", "110 - ", "111 - Protegge il pokémon durante il turno (tipo Protezione)", "112 - Effetto Punte", "113 - Permette il tipo normale contro il tipo spettro", "114 - Effetto Ultimocanto", "115 - Effetto Terrempesta", "116 - Effetto Resistenza", "117 - Per 2-5 turni, i danni sono più alti", "118 - Effetto Bullo", "119 - Effetto Tagliofuria", "120 - Attrae nemici", "121 - Potenza dell'attacco determinata dall'amicizia", "122 - Effetto Regalino", "123 - Effetto Frustazione", "124 - Effetto Salvaguardia", "125 - Scongela il tuo pokémon", "126 - Effetto Magnitudo", "127 - Effetto Staffetta", "128 - Effetto Inseguimento", "129 - Effetto Rapigiro", "130 - Solo 20 PS di danno", "131 - ", "132 - Effetto Mattindoro", "133 - Effetto Sintesi", "134 - Effetto Lucelunare", "135 - Effetto Introforza", "136 - Fa piovere", "137 - Fa sole", "138 - Effetto Alacciaio", "139 - Potrebbe aumentare l'attacco", "140 - Potrebbe aumentare tutte le statistiche", "141 - ", "142 - Effetto Panciamburo", "143 - Effetto Psicamisù", "144 - Effetto Specchiovelo", "145 - Effetto Capocciata?*", "146 - Effetto Tornado", "147 - Doppio danno a chi ha usato Fossa. Colpisce tutti nelle doppie ", "battaglie", "148 - L'attacco colpisce due turni dopo", "149 - Effetto Raffica?*", "150 - Provoca doppio danno ai pokémon minimizzati", "151 - Effetto Solarraggio", "152 - Effetto Tuono", "153 - Lascia la battaglia (Effetto Teletrasporto)", "154 - Effetto Picchiaduro", "155 - Aspetta un turno, poi attacca (effetto Volo)", "156 - Aumenta la difesa di 1. L'effetto raddoppia quando viene usato ", "Rotolamento?*", "157 - Effetto Covauova/Buonlatte", "158 - Effetto Bruciapelo", "159 - Effetto Baraonda", "160 - Effetto Accumulo", "161 - Effetto Sfoghenergia", "162 - Effetto Introenergia", "163 -", "164 - Effetto Grandine", "165 - Effetto Attaccalite", "166 - Effetto Adulazione", "167 - Effetto Fuocofatuo", "168 - Effetto Memento", "169 - Effetto Facciata", "170 - Effetto Centripugno", "171 - Effetto Maniereforti", "172 - Effetto Sonoqui", "173 - Effetto Naturforza", "174 - Effetto Sottocarica", "175 - Effetto Provocazione", "176 - Effetto Altruismo", "177 - Effetto Raggiro", "178 - Effetto Giocodiruolo", "179 - Effetto Desiderio", "180 - Effetto Assistente", "181 - Effetto Radicamento", "182 - Effetto Troppoforte", "183 - Effetto Magivelo", "184 - Effetto Riciclo", "185 - Effetto Vendetta", "186 - Potrebbe distruggere Riflesso", "187 - Effetto Sbadiglio", "188 - Effetto Privazione", "189 - Effetto Rimonta", "190 - Più PS = Più danno", "191 - Effetto Baratto", "192 - Effetto Esclusiva", "193 - Effetto Rinfrescata", "194 - Effetto Rancore", "195 - Effetto Scippo", "196 - Il danno è determinato dal peso del pokémon nemico", "197 - Effetto Forzasegreta", "198 - Contraccolpo = 1/3 del danno", "199 - Effetto Strampadanza", "200 - Effetto Calciardente", "201 - Effetto Fangata", "202 - Effetto Velenzanna", "203 - Effetto Pallaclima", "204 - Dopo l'attacco la difesa sp cala di 2", "205 - Effetto Solletico", "206 - Effetto Cosmoforza", "207 - Effetto Stramontante", "208 - Effetto Granfisico", "209 - Effetto Velencoda", "210 - Effetto Docciascudo", "211 - Effetto Calmamente", "212 - Effetto Dragodanza", "213 - Effetto Camuffamento", "214 -", "215 -", "216 -", "217 -", "218 -", "219 -", "220 -", "221 -", "222 -", "223 -", "224 -", "225 -", "226 -", "227 -", "228 -", "229 -", "230 -", "231 -", "232 -", "233 -", "234 -", "235 -", "236 -", "237 -", "238 -", "239 -", "240 -", "241 -", "242 -", "243 -", "244 -", "245 -", "246 -", "247 -", "248 -", "249 -", "250 -", "251 -", "252 -", "253 -", "254 -", "255 -"})
        Me.cmbEffect.Location = New System.Drawing.Point(70, 132)
        Me.cmbEffect.Name = "cmbEffect"
        Me.cmbEffect.Size = New System.Drawing.Size(263, 21)
        Me.cmbEffect.TabIndex = 5
        '
        'cmbType
        '
        Me.cmbType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbType.Enabled = False
        Me.cmbType.FormattingEnabled = True
        Me.cmbType.Items.AddRange(New Object() {"Normale", "Lotta", "Volante", "Veleno", "Terra", "Roccia", "Coleottero", "Spettro", "Acciaio", "???", "Fuoco", "Acqua", "Erba", "Elettro", "Psico", "Ghiaccio", "Drago", "Buio"})
        Me.cmbType.Location = New System.Drawing.Point(70, 159)
        Me.cmbType.Name = "cmbType"
        Me.cmbType.Size = New System.Drawing.Size(263, 21)
        Me.cmbType.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 162)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Tipo:"
        '
        'cmbTarget
        '
        Me.cmbTarget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbTarget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbTarget.Enabled = False
        Me.cmbTarget.FormattingEnabled = True
        Me.cmbTarget.Items.AddRange(New Object() {"Pokémon avversario", "Il tuo pokémon", "2", "3", "Al secondo avversario (nelle lotte doppie)", "5", "6", "7", "Entrambi gli avversari (nelle lotte doppie)", "9", "10", "11", "12", "13", "14", "15", "Entrambi i tuoi pokémon (nelle lotte doppie)", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200", "201", "202", "203", "204", "205", "206", "207", "208", "209", "210", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "224", "225", "226", "227", "228", "229", "230", "231", "232", "233", "234", "235", "236", "237", "238", "239", "240", "241", "242", "243", "244", "245", "246", "247", "248", "249", "250", "251", "252", "253", "254", "255"})
        Me.cmbTarget.Location = New System.Drawing.Point(70, 185)
        Me.cmbTarget.Name = "cmbTarget"
        Me.cmbTarget.Size = New System.Drawing.Size(263, 21)
        Me.cmbTarget.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 188)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Obiettivo:"
        '
        'Label8
        '
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label8.Location = New System.Drawing.Point(44, 209)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(251, 15)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Copyright © 2012 JackHack96  Matteo Iervasi"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(344, 230)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cmbTarget)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cmbType)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cmbEffect)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbAttack)
        Me.Controls.Add(Me.mnuMain)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuMain
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DPP Attack Editor"
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApriROMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalvaROMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EsciToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AiutoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InformazioniToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmbAttack As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtChance As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtAcc As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPP As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtPower As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbEffect As System.Windows.Forms.ComboBox
    Friend WithEvents cmbType As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmbTarget As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dlgOpen As System.Windows.Forms.OpenFileDialog
    Friend WithEvents LinguaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItalianoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IngleseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class

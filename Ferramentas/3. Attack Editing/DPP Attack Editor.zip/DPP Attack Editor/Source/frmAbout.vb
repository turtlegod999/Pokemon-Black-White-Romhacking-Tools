﻿Public Class frmAbout

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("www.hackromtools.altervista.org")
    End Sub

    Private Sub frmAbout_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim INI As New FileIni("data.ini")
        INI.Carica()
        If (INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = 0) Then
            LinkLabel1.Text = "JackHack96 Official Site - Hack Rom Tools"
            Label2.Text = "Description:"
            Label3.Text = "It edits pokémon's attacks"
            Label9.Text = "Thanks:"
            Label4.Text = "Bisharp, for his excellent beta testing and error-reporting. Pokémon Center forum, for its hints. All the beta tester =D"
        ElseIf (INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = 1) Then
            LinkLabel1.Text = "Sito ufficiale di JackHack96 - Hack Rom Tools"
            Label2.Text = "Descrizione:"
            Label3.Text = "Modifica le mosse pokémon"
            Label9.Text = "Ringraziamenti:"
            Label4.Text = "Bisharp, per l'ottimo beta testing ed error reporting. Il forum di Pokémon Center, per gli ottimi spunti. Tutti i beta tester in generale =D"
        End If
    End Sub
End Class
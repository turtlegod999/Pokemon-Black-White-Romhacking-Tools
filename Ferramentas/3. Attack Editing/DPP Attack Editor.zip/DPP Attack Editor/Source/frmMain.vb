﻿Imports System.IO
Imports System.Text

Public Class frmMain
    Dim PercorsoNARC, PercorsoMSG As String, filePrefix As String
    Dim ROMAperta As Boolean
    Public isVar As Boolean = False
    Dim count As Integer = 0
    Dim MSG As NarcReader, NARC As NarcReader
    Private Sub ApriROMToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ApriROMToolStripMenuItem.Click
        If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
            dlgOpen.Title = "Apri NARC..."
            dlgOpen.Filter = "Archivio NARC (*.narc)|*waza_tbl.narc"
        Else
            dlgOpen.Title = "Open NARC..."
            dlgOpen.Filter = "NARC Archive (*.narc)|*waza_tbl.narc"
        End If
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            PercorsoNARC = dlgOpen.FileName
            ROMAperta = True
            EnableAll()
            If (dlgOpen.SafeFileName = "waza_tbl.narc") Then
                filePrefix = "DP"
            ElseIf (dlgOpen.SafeFileName = "pl_waza_tbl.narc") Then
                filePrefix = "P"
            ElseIf (dlgOpen.SafeFileName = "hgss_waza_tbl.narc") Then
                filePrefix = "HGSS"
            End If
        Else
            Exit Sub
        End If
        dlgOpen.Reset()
        If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
            dlgOpen.Title = "Apri NARC..."
            dlgOpen.Filter = "Archivio NARC (*.narc)|*msg.narc"
        Else
            dlgOpen.Title = "Open NARC..."
            dlgOpen.Filter = "NARC Archive (*.narc)|*msg.narc"
        End If
        If (dlgOpen.ShowDialog = Windows.Forms.DialogResult.OK) Then
            PercorsoMSG = dlgOpen.FileName
            MSG = New NarcReader(PercorsoMSG)
            NARC = New NarcReader(PercorsoNARC)
            LoadLists()
        Else
            Exit Sub
        End If
    End Sub

    Private Sub txtPower_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtPower.KeyPress
        If (Not IsNumeric(e.KeyChar)) And (Asc(e.KeyChar) <> 8) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtPP_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtPP.KeyPress
        If (Not IsNumeric(e.KeyChar)) And (Asc(e.KeyChar) <> 8) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtAcc_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtAcc.KeyPress
        If (Not IsNumeric(e.KeyChar)) And (Asc(e.KeyChar) <> 8) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtChance_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtChance.KeyPress
        If (Not IsNumeric(e.KeyChar)) And (Asc(e.KeyChar) <> 8) Then
            e.Handled = True
        End If
    End Sub

    Private Sub EnableAll()
        cmbAttack.Enabled = True
        cmbEffect.Enabled = True
        cmbTarget.Enabled = True
        cmbType.Enabled = True
        txtAcc.Enabled = True
        txtChance.Enabled = True
        txtPower.Enabled = True
        txtPP.Enabled = True
    End Sub

    Private Sub EsciToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles EsciToolStripMenuItem.Click
        If (ROMAperta = True) Then
            Dim risp As String
            If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
                risp = MsgBox("Hai aperto un NARC. Potresti perdere eventuali modifiche se non le si ha salvate. Chiudere comunque?", vbYesNo, "NARC aperto. Chiudere?")
            Else
                risp = MsgBox("You've loaded a NARC. If you didn't save any changes, you'll lose them. Exit anyway?", vbYesNo, "NARC Loaded. Exit anyway?")
            End If
            If (risp = vbYes) Then
                Me.Close()
            End If
        Else
            Me.Close()
        End If
    End Sub

    Private Sub cmbAttack_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cmbAttack.SelectedIndexChanged
        LoadAttack()
    End Sub
    Private Sub LoadLists()
        Dim MSGFile As New IO.FileStream(PercorsoMSG, IO.FileMode.Open, IO.FileAccess.Read), reader As New BinaryReader(MSGFile)
        If (filePrefix = "DP") Then
            reader.BaseStream.Seek(MSG.fe(589).Ofs, SeekOrigin.Begin)
            readText(reader)
        ElseIf (filePrefix = "P") Then
            reader.BaseStream.Seek(MSG.fe(648).Ofs, SeekOrigin.Begin)
            readText(reader)
        ElseIf (filePrefix = "HGSS") Then
            reader.BaseStream.Seek(MSG.fe(751).Ofs, SeekOrigin.Begin)
            readText(reader)
        End If
        MSGFile.Close()
        reader.Close()
        Dim INI As New FileIni("data.ini")
        INI.Carica()
        If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
            cmbEffect.Items.Clear()
            For i = 0 To 255
                cmbEffect.Items.Add(INI.GetSezioneByNome("ITA Effect List").GetParametroByNome(i).Valore)
            Next
            cmbType.Items.Clear()
            For i = 0 To 17
                cmbType.Items.Add(INI.GetSezioneByNome("ITA Type List").GetParametroByNome(i).Valore)
            Next
            cmbTarget.Items.Clear()
            For i = 0 To 255
                cmbTarget.Items.Add(INI.GetSezioneByNome("ITA Target List").GetParametroByNome(i).Valore)
            Next
        Else
            cmbEffect.Items.Clear()
            For i = 0 To 255
                cmbEffect.Items.Add(INI.GetSezioneByNome("ENG Effect List").GetParametroByNome(i).Valore)
            Next
            cmbType.Items.Clear()
            For i = 0 To 17
                cmbType.Items.Add(INI.GetSezioneByNome("ENG Type List").GetParametroByNome(i).Valore)
            Next
            cmbTarget.Items.Clear()
            For i = 0 To 255
                cmbTarget.Items.Add(INI.GetSezioneByNome("ENG Target List").GetParametroByNome(i).Valore)
            Next
        End If
    End Sub
    Private Sub LoadAttack()
        Dim ROMFile As New FileStream(PercorsoNARC, FileMode.Open, FileAccess.Read), reader As New BinaryReader(ROMFile)
        reader.BaseStream.Seek(NARC.fe(cmbAttack.SelectedIndex).Ofs, SeekOrigin.Begin)
        cmbEffect.SelectedIndex = reader.ReadByte
        ROMFile.Seek(2, IO.SeekOrigin.Current)
        txtPower.Text = reader.ReadByte
        cmbType.SelectedIndex = reader.ReadByte
        txtAcc.Text = reader.ReadByte
        txtPP.Text = reader.ReadByte
        txtChance.Text = reader.ReadByte
        cmbTarget.SelectedIndex = reader.ReadByte
        ROMFile.Close()
    End Sub

    Private Sub WriteAttack(Atk As ComboBox)
        Dim ROMFile As New IO.FileStream(PercorsoNARC, IO.FileMode.Open, IO.FileAccess.Write)
        ROMFile.Seek(NARC.fe(cmbAttack.SelectedIndex).Ofs, SeekOrigin.Begin)
        ROMFile.WriteByte(Convert.ToByte(Hex(cmbEffect.SelectedIndex), 16))
        ROMFile.Seek(2, IO.SeekOrigin.Current)
        ROMFile.WriteByte(Convert.ToByte(Hex(txtPower.Text), 16))
        ROMFile.WriteByte(Convert.ToByte(Hex(cmbType.SelectedIndex), 16))
        ROMFile.WriteByte(Convert.ToByte(Hex(txtAcc.Text), 16))
        ROMFile.WriteByte(Convert.ToByte(Hex(txtPP.Text), 16))
        ROMFile.WriteByte(Convert.ToByte(Hex(txtChance.Text), 16))
        ROMFile.WriteByte(Convert.ToByte(Hex(cmbTarget.SelectedIndex), 16))
        ROMFile.Close()
    End Sub

    Private Sub SalvaROMToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalvaROMToolStripMenuItem.Click
        If (ROMAperta = True) Then
            WriteAttack(cmbAttack)
            If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
                MsgBox("Dati salvati! =)", vbInformation, "DPP Attack Editor")
            Else
                MsgBox("Data saved! =)", vbInformation, "DPP Attack Editor")
            End If
        Else
            If (ApriROMToolStripMenuItem.Text = "Apri NARC...") Then
                MsgBox("Non è aperto alcun NARC!", vbExclamation, "Errore")
            Else
                MsgBox("You didn't load anything!", vbExclamation, "Error")
            End If
        End If
    End Sub

    Private Sub InformazioniToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InformazioniToolStripMenuItem.Click
        frmAbout.Show()
    End Sub

    Private Sub txtPower_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtPower.TextChanged
        If (Len(txtPower.Text) = 3) Then
            If (CInt(txtPower.Text) > 255) Then
                If (ApriROMToolStripMenuItem.Text = "Apri NARC") Then
                    MsgBox("Il valore inserito è maggiore di 255, che è il massimo consentito!", vbExclamation, "Errore")
                Else
                    MsgBox("Typed value is bigger than 255, which is the max value!", vbExclamation, "Error")
                End If
                txtPower.Text = "255"
            End If
        End If
    End Sub

    Private Sub txtPP_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtPP.TextChanged
        If (Len(txtPP.Text) = 3) Then
            If (CInt(txtPP.Text) > 255) Then
                If (ApriROMToolStripMenuItem.Text = "Apri NARC") Then
                    MsgBox("Il valore inserito è maggiore di 255, che è il massimo consentito!", vbExclamation, "Errore")
                Else
                    MsgBox("Typed value is bigger than 255, which is the max value!", vbExclamation, "Error")
                End If
                txtPP.Text = "255"
            End If
        End If
    End Sub

    Private Sub txtAcc_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtAcc.TextChanged
        If (Len(txtAcc.Text) = 3) Then
            If (CInt(txtAcc.Text) > 255) Then
                If (ApriROMToolStripMenuItem.Text = "Apri NARC") Then
                    MsgBox("Il valore inserito è maggiore di 255, che è il massimo consentito!", vbExclamation, "Errore")
                Else
                    MsgBox("Typed value is bigger than 255, which is the max value!", vbExclamation, "Error")
                End If
                txtAcc.Text = "255"
            End If
        End If
    End Sub

    Private Sub txtChance_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtChance.TextChanged
        If (Len(txtChance.Text) = 3) Then
            If (CInt(txtChance.Text) > 255) Then
                If (ApriROMToolStripMenuItem.Text = "Apri NARC") Then
                    MsgBox("Il valore inserito è maggiore di 255, che è il massimo consentito!", vbExclamation, "Errore")
                Else
                    MsgBox("Typed value is bigger than 255, which is the max value!", vbExclamation, "Error")
                End If
                txtChance.Text = "255"
            End If
        End If
    End Sub

    Private Sub ItalianoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ItalianoToolStripMenuItem.Click
        Dim INI As New FileIni("data.ini")
        INI.Carica()
        INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = "1"
        ApriROMToolStripMenuItem.Text = "Apri NARC..."
        SalvaROMToolStripMenuItem.Text = "Salva NARC..."
        EsciToolStripMenuItem.Text = "Esci"
        AiutoToolStripMenuItem.Text = "Aiuto"
        InformazioniToolStripMenuItem.Text = "Informazioni"
        LinguaToolStripMenuItem.Text = "Lingua"
        ItalianoToolStripMenuItem.Text = "Italiano"
        IngleseToolStripMenuItem.Text = "Inglese"
        GroupBox1.Text = "Dati attacco"
        Label2.Text = "Potenza"
        Label3.Text = "PP"
        Label4.Text = "Chance di effetto"
        Label5.Text = "Precisione"
        Label1.Text = "Effetto"
        Label6.Text = "Tipo"
        Label7.Text = "Obiettivo"
        INI.Salva()
    End Sub

    Private Sub IngleseToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles IngleseToolStripMenuItem.Click
        Dim INI As New FileIni("data.ini")
        INI.Carica()
        INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = "0"
        ApriROMToolStripMenuItem.Text = "Open NARC..."
        SalvaROMToolStripMenuItem.Text = "Save NARC..."
        EsciToolStripMenuItem.Text = "Exit"
        AiutoToolStripMenuItem.Text = "Help"
        InformazioniToolStripMenuItem.Text = "About"
        LinguaToolStripMenuItem.Text = "Language"
        ItalianoToolStripMenuItem.Text = "Italian"
        IngleseToolStripMenuItem.Text = "English"
        GroupBox1.Text = "Attack Data"
        Label2.Text = "Power"
        Label3.Text = "PP"
        Label4.Text = "Effect Accuracy"
        Label5.Text = "Accuracy"
        Label1.Text = "Effect"
        Label6.Text = "Type"
        Label7.Text = "Target"
        INI.Salva()
    End Sub

    Private Sub frmMain_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim INI As New FileIni("data.ini")
        INI.Carica()
        If (INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = 0) Then
            ApriROMToolStripMenuItem.Text = "Open NARC..."
            SalvaROMToolStripMenuItem.Text = "Save NARC..."
            EsciToolStripMenuItem.Text = "Exit"
            AiutoToolStripMenuItem.Text = "Help"
            InformazioniToolStripMenuItem.Text = "About"
            LinguaToolStripMenuItem.Text = "Language"
            ItalianoToolStripMenuItem.Text = "Italian"
            IngleseToolStripMenuItem.Text = "English"
            GroupBox1.Text = "Attack Data"
            Label2.Text = "Power"
            Label3.Text = "PP"
            Label4.Text = "Effect Accuracy"
            Label5.Text = "Accuracy"
            Label1.Text = "Effect"
            Label6.Text = "Type"
            Label7.Text = "Target"
        ElseIf (INI.GetSezioneByNome("Options").GetParametroByNome("Language").Valore = 1) Then
            ApriROMToolStripMenuItem.Text = "Apri NARC..."
            SalvaROMToolStripMenuItem.Text = "Salva NARC..."
            EsciToolStripMenuItem.Text = "Esci"
            AiutoToolStripMenuItem.Text = "Aiuto"
            InformazioniToolStripMenuItem.Text = "Informazioni"
            LinguaToolStripMenuItem.Text = "Lingua"
            ItalianoToolStripMenuItem.Text = "Italiano"
            IngleseToolStripMenuItem.Text = "Inglese"
            GroupBox1.Text = "Dati attacco"
            Label2.Text = "Potenza"
            Label3.Text = "PP"
            Label4.Text = "Chance di effetto"
            Label5.Text = "Precisione"
            Label1.Text = "Effetto"
            Label6.Text = "Tipo"
            Label7.Text = "Obiettivo"
        End If
    End Sub

    Private Sub readText(reader As BinaryReader)
        Dim numTextFile As UShort
        Dim key As UInt32
        numTextFile = reader.ReadUInt16
        key = reader.ReadUInt16
        key = (key * &H2FD) And &HFFFF
        Dim textList As New List(Of TextStruct)()
        For i = 0 To numTextFile - 1
            Dim actualTextFile = New TextStruct
            actualTextFile.key2 = (key * (i + 1) And &HFFFF)
            actualTextFile.realKey = actualTextFile.key2 Or (actualTextFile.key2 << 16)
            actualTextFile.startOffset = reader.ReadInt32() Xor actualTextFile.realKey
            actualTextFile.size = reader.ReadInt32() Xor actualTextFile.realKey
            textList.Add(actualTextFile)
        Next
        For i = 0 To numTextFile - 1
            Dim actualTextFile = textList(i)
            key = (&H91BD3 * (i + 1)) And &HFFFF
            Dim str As New StringBuilder()
            isVar = False
            For k = 0 To actualTextFile.size - 1
                If (count = 4) Then
                    str.Append("] ")
                    isVar = False
                    count = 0
                End If
                Dim value = reader.ReadUInt16() Xor key
                Dim car = getCharacter(value)
                If (car = "[]") Then
                    str.Append(" [VAR ")
                    isVar = True
                Else
                    str.Append(car)
                End If
                If (isVar) Then count = count + 1
                key = key + &H493D
                key = key And &HFFFF
            Next
            actualTextFile.text = str.ToString
            cmbAttack.Items.Add(actualTextFile.text)
            textList(i) = actualTextFile
        Next
    End Sub

    Public Structure TextStruct
        Public id As Integer
        Public startOffset As Integer
        Public text As [String]
        Public key2 As Integer
        Public realKey As Integer
        Public size As Integer
    End Structure
End Class
